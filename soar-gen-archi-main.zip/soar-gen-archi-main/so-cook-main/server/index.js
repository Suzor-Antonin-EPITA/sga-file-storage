const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const serverless = require('serverless-http');
require('dotenv').config();

const recipesRoutes = require('./routes/recipes');
const productsRoutes = require('./routes/products');
const surplusRoutes = require('./routes/surplus');
const ordersRoutes = require('./routes/orders');
const usersRoutes = require('./routes/users');

const app = express();
const PORT = process.env.PORT || 5002;

// Middleware
app.use(cors());
app.use(express.json());
app.use('/uploads', express.static('uploads'));

// Middleware to log all requests
app.use((req, res, next) => {
  console.log(`📥 ${req.method} ${req.url} - ${new Date().toISOString()}`);
  next();
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'OK',
    timestamp: new Date().toISOString(),
    port: PORT,
    mongodb: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected'
  });
});

// MongoDB connection
const connectDB = async () => {
  try {
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/socook');
    console.log('✅ Connected to MongoDB');
  } catch (error) {
    console.error('❌ MongoDB connection error:', error);
    process.exit(1);
  }
};

mongoose.connection.on('disconnected', () => {
  console.log('❌ MongoDB disconnected');
});

mongoose.connection.on('error', (err) => {
  console.error('❌ MongoDB error:', err);
});

// API Routes
app.use('/api/recipes', recipesRoutes);
app.use('/api/products', productsRoutes);
app.use('/api/surplus', surplusRoutes);
app.use('/api/orders', ordersRoutes);
app.use('/api/users', usersRoutes);

// API Status endpoint
app.get('/api', (req, res) => {
  res.json({
    message: 'So-Cook API is running!',
    version: '1.0.0',
    endpoints: [
      '/api/recipes',
      '/api/products',
      '/api/surplus',
      '/api/orders',
      '/api/users'
    ]
  });
});

// Root endpoint
app.get('/', (req, res) => {
  res.json({
    message: 'So-Cook Server is running!',
    api: '/api',
    health: '/health'
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// 404 handler
app.use('*', (req, res) => {
  res.status(404).json({ error: `Route not found: ${req.originalUrl}` });
});

// Start server
const startServer = async () => {
  try {
    await connectDB();

    const server = app.listen(PORT, () => {
      console.log(`🚀 Server is running on http://localhost:${PORT}`);
      console.log(`📊 Health check: http://localhost:${PORT}/health`);
      console.log(`🔗 API base: http://localhost:${PORT}/api`);
    });

    // Graceful shutdown
    process.on('SIGTERM', () => {
      console.log('SIGTERM received, shutting down gracefully');
      server.close(() => {
        mongoose.connection.close();
        process.exit(0);
      });
    });

  } catch (error) {
    console.error('❌ Failed to start server:', error);
    process.exit(1);
  }
};

if (!process.env.IS_THIS_LAMBDA) {
  startServer();
} else {
  connectDB();
}

module.exports.handler = serverless(app);
