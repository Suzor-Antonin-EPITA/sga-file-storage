const express = require('express');
const Surplus = require('../models/Surplus');
const router = express.Router();

// GET all surplus
router.get('/', async (req, res) => {
  try {
    const { category, location, maxPrice } = req.query;
    let filter = { expiryDate: { $gte: new Date() } };
    
    if (category) filter.category = category;
    if (location) filter.location = { $regex: location, $options: 'i' };
    if (maxPrice) filter.discountedPrice = { $lte: parseFloat(maxPrice) };
    
    const surplus = await Surplus.find(filter).sort({ expiryDate: 1 });
    res.json(surplus);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET surplus by ID
router.get('/:id', async (req, res) => {
  try {
    const surplus = await Surplus.findById(req.params.id);
    if (!surplus) return res.status(404).json({ error: 'Surplus not found' });
    res.json(surplus);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST create surplus
router.post('/', async (req, res) => {
  try {
    const surplus = new Surplus(req.body);
    await surplus.save();
    res.status(201).json(surplus);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// PUT update surplus
router.put('/:id', async (req, res) => {
  try {
    const surplus = await Surplus.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!surplus) return res.status(404).json({ error: 'Surplus not found' });
    res.json(surplus);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// DELETE surplus
router.delete('/:id', async (req, res) => {
  try {
    const surplus = await Surplus.findByIdAndDelete(req.params.id);
    if (!surplus) return res.status(404).json({ error: 'Surplus not found' });
    res.json({ message: 'Surplus deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST reserve surplus
router.post('/:id/reserve', async (req, res) => {
  try {
    const { quantity } = req.body;
    const surplus = await Surplus.findById(req.params.id);
    
    if (!surplus) return res.status(404).json({ error: 'Surplus not found' });
    if (surplus.reserved + quantity > surplus.availableQuantity) {
      return res.status(400).json({ error: 'Not enough quantity available' });
    }
    
    surplus.reserved += quantity;
    if (surplus.reserved >= surplus.availableQuantity) {
      surplus.status = 'soldout';
    } else if (surplus.reserved >= surplus.availableQuantity * 0.8) {
      surplus.status = 'limited';
    }
    
    await surplus.save();
    res.json(surplus);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;
