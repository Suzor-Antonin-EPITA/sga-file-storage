const express = require('express');
const User = require('../models/User');
const jwt = require('jsonwebtoken');
const router = express.Router();

// POST register
router.post('/register', async (req, res) => {
  try {
    const user = new User(req.body);
    await user.save();
    
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.status(201).json({ user: { ...user.toObject(), password: undefined }, token });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// POST login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ email });
    
    if (!user || !(await user.comparePassword(password))) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }
    
    const token = jwt.sign({ userId: user._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({ user: { ...user.toObject(), password: undefined }, token });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET user cart
router.get('/:id/cart', async (req, res) => {
  try {
    const user = await User.findById(req.params.id).populate('cart.productId');
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user.cart);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// POST add to cart
router.post('/:id/cart', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    
    const existingItem = user.cart.find(item => 
      item.productId.toString() === req.body.productId && 
      item.productType === req.body.productType
    );
    
    if (existingItem) {
      existingItem.quantity += req.body.quantity;
    } else {
      user.cart.push(req.body);
    }
    
    await user.save();
    res.json(user.cart);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// DELETE remove from cart
router.delete('/:id/cart/:itemId', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    
    user.cart.id(req.params.itemId).remove();
    await user.save();
    res.json(user.cart);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// PUT update cart item quantity
router.put('/:id/cart/:itemId', async (req, res) => {
  try {
    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    
    const cartItem = user.cart.id(req.params.itemId);
    if (cartItem) {
      cartItem.quantity = req.body.quantity;
      await user.save();
    }
    
    res.json(user.cart);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

module.exports = router;
