const express = require('express');
const router = express.Router();

function slowFibonacci(n) {
  if (n <= 1) return n;
  return slowFibonacci(n - 1) + slowFibonacci(n - 2);
}

// GET Fibo
router.get('/fibo/:index', async (req, res) => {
  try {
    const fi = slowFibonacci(req.params.index);
    res.json({ res: fi });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
