const mongoose = require('mongoose');

const commentSchema = new mongoose.Schema({
  user: { type: String, required: true },
  text: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
});

const recipeSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  ingredients: [{ type: String, required: true }],
  instructions: [{ type: String, required: true }],
  cookingTime: { type: Number, required: true },
  difficulty: { type: String, enum: ['Facile', 'Moyen', 'Difficile'], required: true },
  category: { type: String, required: true },
  image: { type: String, default: 'https://via.placeholder.com/400x300' },
  author: { type: String, required: true },
  likes: { type: Number, default: 0 },
  likedBy: [{ type: String }],
  comments: [commentSchema],
  localIngredients: { type: Boolean, default: true },
  season: { type: String, enum: ['Printemps', 'Été', 'Automne', 'Hiver', 'Toute saison'], required: true }
}, { timestamps: true });

module.exports = mongoose.model('Recipe', recipeSchema);
