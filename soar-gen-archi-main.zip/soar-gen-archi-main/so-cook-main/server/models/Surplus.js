const mongoose = require('mongoose');

const surplusSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  items: [{ type: String, required: true }],
  originalPrice: { type: Number, required: true },
  discountedPrice: { type: Number, required: true },
  image: { type: String, default: 'https://via.placeholder.com/300x300' },
  seller: { type: String, required: true },
  location: { type: String, required: true },
  availableQuantity: { type: Number, required: true },
  pickupTimeStart: { type: String, required: true },
  pickupTimeEnd: { type: String, required: true },
  expiryDate: { type: Date, required: true },
  category: { type: String, required: true },
  reserved: { type: Number, default: 0 },
  status: { type: String, enum: ['available', 'limited', 'soldout'], default: 'available' }
}, { timestamps: true });

module.exports = mongoose.model('Surplus', surplusSchema);
