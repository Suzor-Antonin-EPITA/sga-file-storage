const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String, required: true },
  price: { type: Number, required: true },
  unit: { type: String, required: true }, // kg, pièce, litre, etc.
  category: { type: String, required: true },
  image: { type: String, default: 'https://via.placeholder.com/300x300' },
  seller: { type: String, required: true },
  location: { type: String, required: true },
  availability: { type: Number, required: true },
  organic: { type: Boolean, default: false },
  local: { type: Boolean, default: true },
  harvestDate: { type: Date },
  rating: { type: Number, default: 0, min: 0, max: 5 },
  reviews: [{
    user: String,
    rating: Number,
    comment: String,
    date: { type: Date, default: Date.now }
  }]
}, { timestamps: true });

module.exports = mongoose.model('Product', productSchema);
