import http from 'k6/http';
import { check } from 'k6';

// Test de pic soudain
export const options = {
  stages: [
    { duration: '10s', target: 10 },   
    { duration: '10s', target: 200 },
    { duration: '30s', target: 200 },
    { duration: '10s', target: 10 },
  ],
};

const BASE_URL = 'https://d3ras5hhig7y90.cloudfront.net';

export default function () {
  const res = http.get(`${BASE_URL}/api/recipes`);
  check(res, { 'status is 200': (r) => r.status === 200 });
}
