# Tests de charge K6

## 📦 Installation

### macOS
```bash
brew install k6
```

### Linux
```bash
# Debian/Ubuntu
sudo gpg -k
sudo gpg --no-default-keyring --keyring /usr/share/keyrings/k6-archive-keyring.gpg --keyserver hkp://keyserver.ubuntu.com:80 --recv-keys C5AD17C747E3415A3642D57D77C6C491D6AC1D69
echo "deb [signed-by=/usr/share/keyrings/k6-archive-keyring.gpg] https://dl.k6.io/deb stable main" | sudo tee /etc/apt/sources.list.d/k6.list
sudo apt-get update
sudo apt-get install k6

# Fedora/CentOS/RedHat
sudo dnf install https://dl.k6.io/rpm/repo.rpm
sudo dnf install k6
```

### Windows
```powershell
choco install k6
# ou
winget install k6 --source winget
```

### Docker
```bash
docker pull grafana/k6
```

---

## 🚀 Lancement des tests

### Test de charge standard (2min30)
```bash
k6 run k6/load-test.js
```

### Test de pic (spike test, 1min)
```bash
k6 run k6/spike-test.js
```

### Après le test
```bash
# Exporter en JSON
k6 run --out json=results.json k6/load-test.js

# Exporter en CSV
k6 run --out csv=results.csv k6/load-test.js
```

---

## ⚙️ Configuration des tests

### load-test.js
- **Durée** : 2min30
- **VUs max** : 100
- **~7200 requêtes** au total

### spike-test.js
- **Durée** : 1min
- **VUs max** : 200
- Test de pic brutal pour voir la résilience

---

## ✅ Critères de succès

- ✅ `http_req_duration p(95) < 500ms`
- ✅ `http_req_failed < 1%`
- ✅ Lambda Throttles = 0
- ✅ API Gateway 5XXError = 0
