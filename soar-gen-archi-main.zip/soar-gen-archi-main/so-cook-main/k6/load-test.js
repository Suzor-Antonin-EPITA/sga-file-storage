import http from 'k6/http';
import { check, sleep } from 'k6';
import { Rate } from 'k6/metrics';

const errorRate = new Rate('errors');

export const options = {
  stages: [
    { duration: '30s', target: 20 },
    { duration: '1m', target: 50 },
    { duration: '30s', target: 100 },
    { duration: '30s', target: 0 },
  ],
  thresholds: {
    http_req_duration: ['p(95)<500'], 
    errors: ['rate<0.1'],             
  },
};

const BASE_URL = 'https://d3ras5hhig7y90.cloudfront.net';

export default function () {
  let res = http.get(`${BASE_URL}/`);
  check(res, {
    'status is 200': (r) => r.status === 200,
    'response time < 500ms': (r) => r.timings.duration < 500,
  }) || errorRate.add(1);

  sleep(1);

  res = http.get(`${BASE_URL}/api/recipes`);
  check(res, {
    'api recipes ok': (r) => r.status === 200,
    'has data': (r) => r.json().length !== undefined,
  }) || errorRate.add(1);

  sleep(1);

  res = http.get(`${BASE_URL}/api/products`);
  check(res, {
    'api products ok': (r) => r.status === 200,
  }) || errorRate.add(1);

  sleep(2);

  res = http.get(`${BASE_URL}/api/surplus`);
  check(res, {
    'api surplus ok': (r) => r.status === 200,
  }) || errorRate.add(1);

  sleep(1);
}
