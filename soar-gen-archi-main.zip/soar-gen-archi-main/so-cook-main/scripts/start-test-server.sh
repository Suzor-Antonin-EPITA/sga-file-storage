#!/bin/bash

# Script pour démarrer le serveur pour les tests
echo "🚀 Démarrage du serveur de test..."

# Vérifier que MongoDB est accessible
if ! mongosh --eval 'db.runCommand("ping").ok' mongodb://localhost:27017/socook_test > /dev/null 2>&1; then
    echo "❌ MongoDB n'est pas accessible"
    exit 1
fi

# Se placer dans le dossier server
cd "$(dirname "$0")/../server"

# Démarrer le serveur avec la base de test
export NODE_ENV=test
export MONGODB_URI=mongodb://localhost:27017/socook_test
export PORT=5002

echo "🔧 Configuration test:"
echo "  - Node ENV: $NODE_ENV"
echo "  - MongoDB: $MONGODB_URI"
echo "  - Port: $PORT"

# Démarrer le serveur
npm start
