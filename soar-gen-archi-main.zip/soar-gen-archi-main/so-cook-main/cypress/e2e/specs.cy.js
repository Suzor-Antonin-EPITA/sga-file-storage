Cypress.Commands.add('login', (email, password) => {
    cy.visit('http://localhost:3000');
    cy.get('.space-x-4 > .btn-primary').click();
    cy.get(':nth-child(1) > .input').type(email);
    cy.get(':nth-child(2) > .input').type(password);
    cy.get('.space-y-4 > .btn-primary').click();
});

describe('template spec', () => {
  it('Visit local web site', () => {
    cy.visit('http://localhost:3000/')
  });

  it('Create account', function() {
    cy.visit('http://localhost:3000');
    cy.get('.space-x-4 > .btn-primary').click();
    cy.get('.mt-4 > .text-primary-400').click();
    cy.get(':nth-child(1) > .input').type('Test');
    cy.get(':nth-child(2) > .input').type('test.test@gmail.com');
    cy.get(':nth-child(3) > .input').type('test');
    cy.get(':nth-child(4) > .input').type('test');
    cy.get('.rounded').check();
    cy.get('.space-y-4 > .btn-primary').click();
  });

  it('create recipe', function() {
    cy.login("test.test@gmail.com", "test");
    /* ==== Generated with Cypress Studio ==== */
    cy.get('.flex > .btn-primary').contains("Découvrir les recettes").click();
    cy.get('.btn-primary').click();
    cy.get(':nth-child(1) > :nth-child(1) > .input').type('Test Recipe');
    cy.get('.grid-cols-1 > :nth-child(1) > :nth-child(2) > .input').type('Test Recipe Description Apagnan QUoicoubananen hihihi hahahah');
    cy.get(':nth-child(3) > :nth-child(1) > .input').type('15');
    cy.get('.btn-primary').click();
    /* ==== End Cypress Studio ==== */
  });

  it('create product', function() {
    cy.login("test.test@gmail.com", "test", true);
    /* ==== Generated with Cypress Studio ==== */
    cy.get('.btn-secondary').click();
    cy.get('.btn-primary').contains("Ajouter un produit").click();
    cy.get('.card > :nth-child(1) > .input').type('Test Produit');
    cy.get('.card > :nth-child(2) > .input').type('Test Produit Description Apagnan QUoicoubananen hihihi hahahah');
    cy.get(':nth-child(3) > :nth-child(1) > .input').type('15');
    cy.get(':nth-child(5) > :nth-child(1) > .input').type('12 rue Lieu Fictif');
    cy.get(':nth-child(5) > :nth-child(2) > .input').type('42');
    cy.get(':nth-child(7) > .input').click();
    cy.get('.btn-primary').click();
    /* ==== End Cypress Studio ==== */
  });
})