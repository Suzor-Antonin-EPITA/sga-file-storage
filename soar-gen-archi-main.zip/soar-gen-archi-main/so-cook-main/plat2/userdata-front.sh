#!/bin/bash
set -eux

# --- MAJ + Nginx + Node.js ---
dnf -y update
dnf -y install nginx unzip
curl -fsSL https://rpm.nodesource.com/setup_20.x | bash -
dnf -y install nodejs

# --- Télécharger le projet ---
aws s3 cp s3://sc-plat2-app-bucket/soar-gen-archi.zip /tmp/app.zip
mkdir -p /opt/app
unzip /tmp/app.zip -d /opt/app

# --- Build du frontend ---
cd /opt/app/soar-gen-archi/so-cook-main/client
npm install
npm run build

mkdir -p /var/www/app
cp -r dist/* /var/www/app/

# --- Configurer Nginx pour servir le front ---
cat > /etc/nginx/conf.d/socook.conf <<'EOF'
server {
    listen 80 default_server;
    server_name _;
    location / {
        root /var/www/app;
        index index.html;
        try_files $uri /index.html;
    }
}
EOF

sudo systemctl enable nginx
sudo systemctl restart nginx

echo "✅ Frontend running via Nginx"