#!/bin/bash
set -eux

echo "🚀 Installing MongoDB Community Edition (Amazon Linux 2023)"

# --- MAJ système ---
dnf -y update

# --- Installer jq pour parser JSON ---
dnf install -y jq

# --- Ajouter le dépôt RHEL9 compatible ---
cat <<EOF | sudo tee /etc/yum.repos.d/mongodb-org.repo
[mongodb-org-7.0]
name=MongoDB Repository
baseurl=https://repo.mongodb.org/yum/redhat/9/mongodb-org/7.0/x86_64/
gpgcheck=1
enabled=1
gpgkey=https://pgp.mongodb.com/server-7.0.asc
EOF

# --- Installer MongoDB ---
dnf install -y mongodb-org

# --- Récupérer les informations de l'instance ---
INSTANCE_ID=$(ec2-metadata --instance-id | cut -d " " -f 2)
REGION=$(ec2-metadata --availability-zone | cut -d " " -f 2 | sed 's/[a-z]$//')
PRIVATE_IP=$(ec2-metadata --local-ipv4 | cut -d " " -f 2)

echo "Instance ID: $INSTANCE_ID"
echo "Region: $REGION"
echo "Private IP: $PRIVATE_IP"

# --- Configurer MongoDB pour écouter sur toutes les interfaces et activer la réplication ---
cat <<EOF > /etc/mongod.conf
# mongod.conf
storage:
  dbPath: /var/lib/mongo

systemLog:
  destination: file
  logAppend: true
  path: /var/log/mongodb/mongod.log

net:
  port: 27017
  bindIp: 0.0.0.0

processManagement:
  timeZoneInfo: /usr/share/zoneinfo

replication:
  replSetName: "soarcook-rs"
EOF

# --- Démarrer MongoDB ---
sudo systemctl start mongod
sudo systemctl enable mongod

# --- Attendre que MongoDB soit prêt ---
echo "⏳ Waiting for MongoDB to be ready..."
sleep 10

# --- Découvrir les autres instances MongoDB dans l'ASG ---
echo "🔍 Discovering other MongoDB instances..."
DB_INSTANCES=$(aws ec2 describe-instances \
  --region "$REGION" \
  --filters "Name=tag:Role,Values=database" "Name=instance-state-name,Values=running" \
  --query 'Reservations[*].Instances[*].[InstanceId,PrivateIpAddress]' \
  --output json | jq -r '.[][] | @tsv')

echo "Found instances:"
echo "$DB_INSTANCES"

# --- Compter le nombre d'instances et construire la liste ---
INSTANCE_COUNT=$(echo "$DB_INSTANCES" | wc -l)
INSTANCE_IPS=$(echo "$DB_INSTANCES" | awk '{print $2}' | sort)

echo "Total MongoDB instances: $INSTANCE_COUNT"
echo "Instance IPs: $INSTANCE_IPS"

# --- Déterminer si c'est la première instance (par ordre alphabétique d'IP) ---
FIRST_IP=$(echo "$INSTANCE_IPS" | head -n 1)

if [ "$PRIVATE_IP" == "$FIRST_IP" ]; then
  echo "🎯 This is the PRIMARY instance. Initializing replica set..."
  
  # Attendre un peu pour s'assurer que MongoDB est complètement prêt
  sleep 5
  
  # Vérifier si le replica set existe déjà
  RS_STATUS=$(mongosh --quiet --eval "rs.status().ok" || echo "0")
  
  if [ "$RS_STATUS" == "1" ]; then
    echo "✅ Replica set already initialized"
  else
    echo "📝 Initializing new replica set..."
    
    # Construire la configuration du replica set
    MEMBERS=""
    MEMBER_ID=0
    for IP in $INSTANCE_IPS; do
      if [ -n "$MEMBERS" ]; then
        MEMBERS="$MEMBERS,"
      fi
      MEMBERS="$MEMBERS{ _id: $MEMBER_ID, host: \"$IP:27017\" }"
      MEMBER_ID=$((MEMBER_ID + 1))
    done
    
    # Initialiser le replica set
    mongosh --eval "rs.initiate({ _id: 'soarcook-rs', members: [ $MEMBERS ] })"
    
    echo "✅ Replica set initialized with $INSTANCE_COUNT member(s)"
  fi
else
  echo "⏳ This is a SECONDARY instance. Waiting for primary to initialize..."
  
  # Attendre que le replica set soit initialisé par la première instance
  MAX_ATTEMPTS=60
  ATTEMPT=0
  
  while [ $ATTEMPT -lt $MAX_ATTEMPTS ]; do
    # Vérifier si on peut déjà se connecter au replica set
    RS_STATUS=$(mongosh --host "$FIRST_IP:27017" --quiet --eval "rs.status().ok" 2>/dev/null || echo "0")
    
    if [ "$RS_STATUS" == "1" ]; then
      echo "✅ Primary replica set detected!"
      
      # Vérifier si cette instance est déjà membre
      IS_MEMBER=$(mongosh --quiet --eval "rs.status().members.filter(m => m.name.includes('$PRIVATE_IP')).length" || echo "0")
      
      if [ "$IS_MEMBER" == "0" ]; then
        echo "📝 Adding this instance to the replica set..."
        mongosh --host "$FIRST_IP:27017" --eval "rs.add('$PRIVATE_IP:27017')"
        echo "✅ Successfully joined replica set"
      else
        echo "✅ Already a member of the replica set"
      fi
      break
    fi
    
    ATTEMPT=$((ATTEMPT + 1))
    echo "Attempt $ATTEMPT/$MAX_ATTEMPTS: Waiting for primary..."
    sleep 5
  done
  
  if [ $ATTEMPT -eq $MAX_ATTEMPTS ]; then
    echo "⚠️  Timeout waiting for primary. Manual intervention may be required."
  fi
fi

echo "✅ MongoDB replica set configuration complete"
echo "📊 Replica set status:"
mongosh --quiet --eval "rs.status()" || echo "Unable to retrieve status"
