export default {
  testEnvironment: 'node',
  transform: {
    '^.+\\.(js|jsx)$': 'babel-jest',
  },
  moduleFileExtensions: ['js', 'jsx', 'json'],
  testMatch: [
    '<rootDir>/src/**/__tests__/**/*.(js|jsx)',
    '<rootDir>/src/**/?(*.)(test|spec).(js|jsx)'
  ],
  collectCoverageFrom: [
    'src/services/**/*.(js|jsx)',
    '!src/**/*.test.(js|jsx)',
    '!src/main.jsx',
    '!src/index.css',
    '!src/pages/**/*',
    '!src/components/**/*'
  ],
  setupFilesAfterEnv: ['<rootDir>/src/setupTests.js'],
  testTimeout: 30000, // 30 secondes pour les tests d'API
  verbose: true,
  // Séparation des tests
  projects: [
    {
      displayName: 'unit',
      testMatch: ['<rootDir>/src/**/__tests__/**/unit.test.(js|jsx)'],
      testEnvironment: 'node'
    },
    {
      displayName: 'integration', 
      testMatch: ['<rootDir>/src/**/__tests__/**/integration.test.(js|jsx)'],
      testEnvironment: 'node'
    }
  ]
};
