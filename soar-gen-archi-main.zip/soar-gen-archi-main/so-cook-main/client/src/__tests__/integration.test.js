import axios from 'axios';

// Configuration de l'API pour les tests
const api = axios.create({
  baseURL: process.env.API_BASE_URL || 'http://localhost:5002/api',
  headers: {
    'Content-Type': 'application/json',
  },
  timeout: 10000
});

// Fonction pour nettoyer les données de test
const cleanupTestData = async () => {
  try {
    // Nettoyer les utilisateurs de test
    const users = await api.get('/users').catch(() => ({ data: [] }));
    for (const user of users.data || []) {
      if (user.username && user.username.includes('testuser_')) {
        await api.delete(`/users/${user._id}`).catch(() => {});
      }
    }
    
    // Nettoyer les produits de test
    const products = await api.get('/products').catch(() => ({ data: [] }));
    for (const product of products.data || []) {
      if (product.name && product.name.includes('Test')) {
        await api.delete(`/products/${product._id}`).catch(() => {});
      }
    }
    
    // Nettoyer les recettes de test
    const recipes = await api.get('/recipes').catch(() => ({ data: [] }));
    for (const recipe of recipes.data || []) {
      if (recipe.title && recipe.title.includes('Test')) {
        await api.delete(`/recipes/${recipe._id}`).catch(() => {});
      }
    }
  } catch (error) {
    console.warn('Cleanup warning:', error.message);
  }
};

describe('SoCook API Integration Tests', () => {
  let testUserId;
  let testProductId;
  let testRecipeId;
  
  beforeAll(async () => {
    // Vérifier que l'API est accessible avant de commencer les tests
    try {
      await api.get('/');
      console.log('✅ API is accessible');
      
      // Nettoyer les données de test précédentes
      await cleanupTestData();
      console.log('✅ Test data cleaned up');
      
    } catch (error) {
      console.error('❌ API not accessible:', error.message);
      throw new Error('API server is not running or not accessible');
    }
  });

  afterAll(async () => {
    // Nettoyer après tous les tests
    await cleanupTestData();
    console.log('✅ Final cleanup completed');
  });

  describe('Authentication Tests', () => {
    test('should register a new user successfully', async () => {
      const timestamp = Date.now();
      const testUser = {
        username: `testuser_${timestamp}`,
        email: `test_${timestamp}@example.com`,
        password: 'testpassword123',
        location: 'Paris Test',
        bio: 'Utilisateur de test créé automatiquement'
      };

      const response = await api.post('/users/register', testUser);
      
      expect(response.status).toBe(201);
      expect(response.data).toHaveProperty('user');
      expect(response.data).toHaveProperty('token');
      expect(response.data.user.username).toBe(testUser.username);
      expect(response.data.user.email).toBe(testUser.email);
      expect(response.data.user.password).toBeUndefined(); // Le mot de passe ne doit pas être retourné

      testUserId = response.data.user._id;
    });

    test('should login with created user credentials', async () => {
      const timestamp = Date.now();
      const testUser = {
        username: `logintest_${timestamp}`,
        email: `logintest_${timestamp}@example.com`,
        password: 'testpassword123'
      };

      // D'abord créer l'utilisateur
      const registerResponse = await api.post('/users/register', testUser);
      expect(registerResponse.status).toBe(201);

      // Ensuite se connecter
      const loginResponse = await api.post('/users/login', {
        email: testUser.email,
        password: testUser.password
      });

      expect(loginResponse.status).toBe(200);
      expect(loginResponse.data).toHaveProperty('user');
      expect(loginResponse.data).toHaveProperty('token');
      expect(loginResponse.data.user.email).toBe(testUser.email);
    });

    test('should fail login with wrong credentials', async () => {
      try {
        await api.post('/users/login', {
          email: 'wrong@example.com',
          password: 'wrongpassword'
        });
        // Si on arrive ici, le test doit échouer
        fail('Login should have failed with wrong credentials');
      } catch (error) {
        expect(error.response.status).toBe(401);
        expect(error.response.data).toHaveProperty('error');
      }
    });
  });

  describe('Cart System Tests', () => {
    let cartUserId;

    beforeAll(async () => {
      // Créer un utilisateur pour les tests de panier
      const timestamp = Date.now();
      const cartUser = {
        username: `cartuser_${timestamp}`,
        email: `carttest_${timestamp}@example.com`,
        password: 'testpassword123'
      };
      
      const userResponse = await api.post('/users/register', cartUser);
      cartUserId = userResponse.data.user._id;

      // Créer un produit pour les tests de panier
      const testProduct = {
        name: 'Produit Test Panier',
        description: 'Produit créé pour tester le panier',
        price: 5.99,
        unit: 'pièce',
        category: 'Test',
        seller: 'Test Seller',
        location: 'Test Location',
        availability: 10,
        organic: false,
        local: true
      };
      
      const productResponse = await api.post('/products', testProduct);
      testProductId = productResponse.data._id;
    });

    test('should add product to user cart', async () => {
      const cartItem = {
        productId: testProductId,
        productType: 'product',
        quantity: 2
      };
      
      const response = await api.post(`/users/${cartUserId}/cart`, cartItem);
      
      expect(response.status).toBe(200);
      expect(Array.isArray(response.data)).toBe(true);
      expect(response.data.length).toBeGreaterThan(0);
      
      const addedItem = response.data.find(item => 
        item.productId === testProductId && item.productType === 'product'
      );
      expect(addedItem).toBeDefined();
      expect(addedItem.quantity).toBe(2);
    });

    test('should get user cart', async () => {
      const response = await api.get(`/users/${cartUserId}/cart`);
      
      expect(response.status).toBe(200);
      expect(Array.isArray(response.data)).toBe(true);
    });

    test('should update cart item quantity', async () => {
      // D'abord récupérer le panier pour obtenir l'ID de l'item
      const cartResponse = await api.get(`/users/${cartUserId}/cart`);
      const cartItem = cartResponse.data.find(item => item.productId === testProductId);
      
      expect(cartItem).toBeDefined();
      
      // Mettre à jour la quantité
      const updateResponse = await api.put(`/users/${cartUserId}/cart/${cartItem._id}`, {
        quantity: 5
      });
      
      expect(updateResponse.status).toBe(200);
      const updatedItem = updateResponse.data.find(item => item._id === cartItem._id);
      expect(updatedItem.quantity).toBe(5);
    });
  });

  describe('Recipe Comments Tests', () => {
    beforeAll(async () => {
      // Créer une recette pour les tests de commentaires
      const testRecipe = {
        title: `Recette Test Commentaire ${Date.now()}`,
        description: 'Recette créée pour tester les commentaires',
        ingredients: ['Ingrédient test'],
        instructions: ['Instruction test'],
        cookingTime: 10,
        difficulty: 'Facile',
        category: 'Test',
        author: 'TestBot',
        season: 'Toute saison'
      };
      
      const recipeResponse = await api.post('/recipes', testRecipe);
      testRecipeId = recipeResponse.data._id;
    });

    test('should add comment to recipe', async () => {
      const testComment = {
        user: `TestUser_${Date.now()}`,
        text: 'Excellent! Cette recette est vraiment délicieuse. Je la recommande vivement!'
      };
      
      const response = await api.post(`/recipes/${testRecipeId}/comments`, testComment);
      
      expect(response.status).toBe(200);
      expect(response.data).toHaveProperty('comments');
      expect(Array.isArray(response.data.comments)).toBe(true);
      expect(response.data.comments.length).toBeGreaterThan(0);
      
      const addedComment = response.data.comments[response.data.comments.length - 1];
      expect(addedComment.user).toBe(testComment.user);
      expect(addedComment.text).toBe(testComment.text);
      expect(addedComment).toHaveProperty('_id');
      expect(addedComment).toHaveProperty('createdAt');
    });

    test('should get recipe with comments', async () => {
      const response = await api.get(`/recipes/${testRecipeId}`);
      
      expect(response.status).toBe(200);
      expect(response.data).toHaveProperty('comments');
      expect(Array.isArray(response.data.comments)).toBe(true);
      expect(response.data.comments.length).toBeGreaterThan(0);
    });

    test('should fail to add comment with missing data', async () => {
      try {
        await api.post(`/recipes/${testRecipeId}/comments`, {
          user: 'TestUser'
          // text manquant
        });
        fail('Comment creation should have failed with missing text');
      } catch (error) {
        expect(error.response.status).toBe(400);
      }
    });
  });

  describe('API Health Tests', () => {
    test('should return API status', async () => {
      const response = await api.get('/');
      
      expect(response.status).toBe(200);
      expect(response.data).toHaveProperty('message');
      expect(response.data.message).toContain('So-Cook');
    });

    test('should get recipes list', async () => {
      const response = await api.get('/recipes');
      
      expect(response.status).toBe(200);
      expect(Array.isArray(response.data)).toBe(true);
    });

    test('should get products list', async () => {
      const response = await api.get('/products');
      
      expect(response.status).toBe(200);
      expect(Array.isArray(response.data)).toBe(true);
    });

    test('should get surplus list', async () => {
      const response = await api.get('/surplus');
      
      expect(response.status).toBe(200);
      expect(Array.isArray(response.data)).toBe(true);
    });
  });
});
