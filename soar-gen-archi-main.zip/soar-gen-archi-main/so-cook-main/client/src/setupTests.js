// Configuration pour les tests
global.fetch = require('node-fetch');

// Variables d'environnement pour les tests
process.env.API_BASE_URL = process.env.API_BASE_URL || 'http://localhost:5002/api';
process.env.NODE_ENV = 'test';
