import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Clock, MapPin, ShoppingCart, AlertTriangle, Package, TrendingDown } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const SurplusCard = ({ surplus, onAddToCart }) => {
  const [quantity, setQuantity] = useState(1);
  const [adding, setAdding] = useState(false);
  const { user } = useAuth();

  const handleAddToCart = async (e) => {
    e.preventDefault();
    if (!user) {
      alert('Veuillez vous connecter pour réserver ce surplus');
      return;
    }

    try {
      setAdding(true);
      await onAddToCart(surplus, quantity, 'surplus');
    } catch (error) {
      console.error('Error adding to cart:', error);
    } finally {
      setAdding(false);
    }
  };

  const getStatusInfo = (status, availableQuantity, reserved) => {
    const remaining = availableQuantity - reserved;
    switch (status) {
      case 'available':
        return { text: `${remaining} disponibles`, color: 'text-green-400', bgColor: 'bg-green-400/10' };
      case 'limited':
        return { text: `Plus que ${remaining}`, color: 'text-yellow-400', bgColor: 'bg-yellow-400/10' };
      case 'soldout':
        return { text: 'Épuisé', color: 'text-red-400', bgColor: 'bg-red-400/10' };
      default:
        return { text: 'Indisponible', color: 'text-dark-400', bgColor: 'bg-dark-800' };
    }
  };

  const statusInfo = getStatusInfo(surplus.status, surplus.availableQuantity, surplus.reserved);
  const discountPercentage = Math.round((1 - surplus.discountedPrice / surplus.originalPrice) * 100);
  const hoursUntilExpiry = Math.ceil((new Date(surplus.expiryDate) - new Date()) / (1000 * 60 * 60));

  return (
    <Link to={`/surplus/${surplus._id}`} className="block">
      <div className="card hover:scale-105 transform transition-all duration-200 relative overflow-hidden">
        {/* Discount Badge */}
        <div className="absolute top-4 left-4 z-10">
          <div className="bg-red-500 text-white px-2 py-1 rounded-full text-sm font-bold flex items-center">
            <TrendingDown className="w-4 h-4 mr-1" />
            -{discountPercentage}%
          </div>
        </div>

        {/* Status Badge */}
        <div className="absolute top-4 right-4 z-10">
          <div className={`${statusInfo.bgColor} bg-opacity-20 ${statusInfo.color} px-2 py-1 rounded-full text-xs font-medium border border-current`}>
            {statusInfo.text}
          </div>
        </div>

        {/* Image */}
        <div className="h-48 bg-dark-800 overflow-hidden">
          <img
            src={surplus.image}
            alt={surplus.title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Content */}
        <div className="p-4">
          <h3 className="text-lg font-semibold text-white mb-2 line-clamp-2">
            {surplus.title}
          </h3>
          
          <p className="text-dark-300 text-sm mb-3 line-clamp-2">
            {surplus.description}
          </p>

          {/* Items */}
          <div className="mb-3">
            <p className="text-dark-400 text-xs mb-1">Contient :</p>
            <div className="flex flex-wrap gap-1">
              {surplus.items.slice(0, 3).map((item, index) => (
                <span key={index} className="bg-dark-800 text-dark-300 px-2 py-1 rounded text-xs">
                  {item}
                </span>
              ))}
              {surplus.items.length > 3 && (
                <span className="text-dark-400 text-xs">+{surplus.items.length - 3} autres</span>
              )}
            </div>
          </div>

          {/* Location and Time */}
          <div className="space-y-1 mb-4">
            <div className="flex items-center text-dark-300 text-sm">
              <MapPin className="w-4 h-4 mr-2 text-primary-400" />
              {surplus.location}
            </div>
            <div className="flex items-center text-dark-300 text-sm">
              <Clock className="w-4 h-4 mr-2 text-primary-400" />
              {surplus.pickupTimeStart} - {surplus.pickupTimeEnd}
            </div>
          </div>

          {/* Price and CTA */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <span className="text-dark-500 line-through text-sm">
                {surplus.originalPrice.toFixed(2)}€
              </span>
              <span className="text-primary-400 font-bold text-lg">
                {surplus.discountedPrice.toFixed(2)}€
              </span>
            </div>
            
            {surplus.status !== 'soldout' && (
              <button
                onClick={handleAddToCart}
                className="bg-primary-600 hover:bg-primary-700 text-white p-2 rounded-lg transition-colors duration-200"
              >
                <ShoppingCart className="w-5 h-5" />
              </button>
            )}
          </div>

          {/* Availability */}
          <div className="mt-3 text-xs text-dark-400">
            {surplus.availableQuantity - surplus.reserved} sur {surplus.availableQuantity} disponible{surplus.availableQuantity > 1 ? 's' : ''}
          </div>
        </div>
      </div>
    </Link>
  );
};

export default SurplusCard;