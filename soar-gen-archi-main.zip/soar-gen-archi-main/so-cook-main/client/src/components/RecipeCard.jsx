import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Heart, Clock, Users, Leaf } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';

const RecipeCard = ({ recipe, onUpdate }) => {
  const [isLiked, setIsLiked] = useState(false);
  const [likesCount, setLikesCount] = useState(recipe.likes);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  const handleLike = async (e) => {
    e.preventDefault();
    if (!user) return;

    try {
      setLoading(true);
      const response = await api.post(`/recipes/${recipe._id}/like`, {
        userId: user._id
      });
      
      setLikesCount(response.data.likes);
      setIsLiked(response.data.likedBy.includes(user._id));
    } catch (error) {
      console.error('Error liking recipe:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Êtes-vous sûr de vouloir supprimer cette recette ?')) {
      return;
    }

    try {
      await api.delete(`/recipes/${recipe._id}`);
      onUpdate();
    } catch (error) {
      console.error('Error deleting recipe:', error);
    }
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Facile': return 'text-green-400 bg-green-400';
      case 'Moyen': return 'text-yellow-400 bg-yellow-400';
      case 'Difficile': return 'text-red-400 bg-red-400';
      default: return 'text-dark-300 bg-dark-300';
    }
  };

  const difficultyColor = getDifficultyColor(recipe.difficulty);

  return (
    <Link to={`/recipes/${recipe._id}`} className="block">
      <div className="card hover:scale-105 transform transition-all duration-200 relative overflow-hidden">
        {/* Local Badge */}
        {recipe.localIngredients && (
          <div className="absolute top-4 left-4 z-10">
            <div className="bg-green-500 bg-opacity-20 text-green-400 px-2 py-1 rounded-full text-xs font-medium border border-green-400 flex items-center">
              <Leaf className="w-3 h-3 mr-1" />
              Local
            </div>
          </div>
        )}

        {/* Difficulty Badge */}
        <div className="absolute top-4 right-4 z-10">
          <div className={`${difficultyColor} bg-opacity-20 px-2 py-1 rounded-full text-xs font-medium border border-current`}>
            {recipe.difficulty}
          </div>
        </div>

        {/* Image */}
        <div className="h-48 bg-dark-800 overflow-hidden">
          <img
            src={recipe.image}
            alt={recipe.title}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Content */}
        <div className="p-4">
          <h3 className="text-lg font-semibold text-white mb-2 line-clamp-2">
            {recipe.title}
          </h3>
          
          <p className="text-dark-300 text-sm mb-3 line-clamp-2">
            {recipe.description}
          </p>

          {/* Meta Info */}
          <div className="flex items-center justify-between text-sm text-dark-400 mb-4">
            <div className="flex items-center">
              <Clock className="w-4 h-4 mr-1" />
              {recipe.cookingTime} min
            </div>
            <div className="flex items-center">
              <Users className="w-4 h-4 mr-1" />
              {recipe.author}
            </div>
          </div>

          {/* Season */}
          <div className="mb-4">
            <span className="bg-primary-600 bg-opacity-20 text-primary-300 px-2 py-1 rounded text-xs">
              {recipe.season}
            </span>
          </div>

          {/* Like Button */}
          <div className="flex items-center justify-between">
            <span className="text-dark-400 text-sm">{recipe.category}</span>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default RecipeCard;
