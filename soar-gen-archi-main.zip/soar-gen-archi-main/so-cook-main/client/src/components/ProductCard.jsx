import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Star, MapPin, Leaf, ShoppingCart } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const ProductCard = ({ product, onAddToCart }) => {
  const [quantity, setQuantity] = useState(1);
  const [adding, setAdding] = useState(false);
  const { user } = useAuth();

  const handleAddToCart = async (e) => {
    e.preventDefault();
    if (!user) {
      alert('Veuillez vous connecter pour ajouter des produits au panier');
      return;
    }

    try {
      setAdding(true);
      await onAddToCart(product, quantity);
    } catch (error) {
      console.error('Error adding to cart:', error);
    } finally {
      setAdding(false);
    }
  };

  const renderStars = (rating) => {
    return [...Array(5)].map((_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${
          i < Math.floor(rating) 
            ? 'text-yellow-400 fill-current' 
            : 'text-dark-600'
        }`}
      />
    ));
  };

  return (
    <Link to={`/marketplace/${product._id}`} className="card group">
      <div className="relative">
        <img
          src={product.image}
          alt={product.name}
          className="w-full h-48 object-cover"
        />
        <div className="absolute top-4 right-4 flex flex-col gap-2">
          {product.organic && (
            <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-600 text-white flex items-center">
              <Leaf className="w-3 h-3 mr-1" />
              Bio
            </span>
          )}
          {product.local && (
            <span className="px-2 py-1 rounded-full text-xs font-medium bg-blue-600 text-white">
              Local
            </span>
          )}
        </div>
        {product.availability <= 5 && (
          <div className="absolute top-4 left-4">
            <span className="px-2 py-1 rounded-full text-xs font-medium bg-red-600 text-white">
              Stock limité
            </span>
          </div>
        )}
      </div>

      <div className="p-4">
        <h3 className="text-lg font-semibold text-white mb-1 group-hover:text-primary-400 transition-colors">
          {product.name}
        </h3>
        <p className="text-dark-300 text-sm mb-3 line-clamp-2">
          {product.description}
        </p>

        <div className="flex items-center mb-3">
          <div className="flex items-center">
            {renderStars(product.rating)}
          </div>
          <span className="text-sm text-dark-400 ml-2">
            ({product.reviews?.length || 0})
          </span>
        </div>

        <div className="flex items-center text-sm text-dark-400 mb-3">
          <MapPin className="w-4 h-4 mr-1" />
          {product.location}
        </div>

        <div className="flex items-center justify-between mb-4">
          <div>
            <span className="text-xl font-bold text-white">
              {product.price}€
            </span>
            <span className="text-sm text-dark-400 ml-1">
              / {product.unit}
            </span>
          </div>
          <span className="text-sm text-dark-400">
            Par {product.seller}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <select
            value={quantity}
            onChange={(e) => setQuantity(parseInt(e.target.value))}
            className="input text-sm flex-1"
            onClick={(e) => e.preventDefault()}
          >
            {[...Array(Math.min(10, product.availability))].map((_, i) => (
              <option key={i + 1} value={i + 1}>
                {i + 1}
              </option>
            ))}
          </select>
          <button
            onClick={handleAddToCart}
            disabled={adding || !user}
            className="btn-primary flex items-center px-3 py-2 text-sm disabled:opacity-50"
          >
            <ShoppingCart className="w-4 h-4 mr-1" />
            {adding ? '...' : 'Ajouter'}
          </button>
        </div>

        {product.harvestDate && (
          <div className="mt-3 pt-3 border-t border-dark-800">
            <span className="text-xs text-dark-500">
              Récolté le {new Date(product.harvestDate).toLocaleDateString('fr-FR')}
            </span>
          </div>
        )}
      </div>
    </Link>
  );
};

export default ProductCard;
