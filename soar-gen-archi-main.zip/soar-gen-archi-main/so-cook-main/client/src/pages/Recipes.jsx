import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Search, Filter, Plus } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";
import RecipeCard from "../components/RecipeCard";

const Recipes = () => {
  const [recipes, setRecipes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");
  const [filters, setFilters] = useState({
    category: "",
    difficulty: "",
    season: "",
  });
  const [showFilters, setShowFilters] = useState(false);
  const { user } = useAuth();

  const categories = [
    "Entrées",
    "Plats",
    "Desserts",
    "Soupes",
    "Salades",
    "Snacks",
  ];
  const difficulties = ["Facile", "Moyen", "Difficile"];
  const seasons = ["Printemps", "Été", "Automne", "Hiver", "Toute saison"];

  useEffect(() => {
    fetchRecipes();
  }, [filters]);

  const fetchRecipes = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();

      Object.entries(filters).forEach(([key, value]) => {
        if (value !== "") {
          params.append(key, value);
        }
      });

      const response = await api.get(`/recipes?${params.toString()}`);
      setRecipes(response.data);
    } catch (error) {
      console.error("Error fetching recipes:", error);
    } finally {
      setLoading(false);
    }
  };

  const filteredRecipes = recipes.filter(
    (recipe) =>
      recipe.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      recipe.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      recipe.author.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleFilterChange = (key, value) => {
    setFilters((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const clearFilters = () => {
    setFilters({
      category: "",
      difficulty: "",
      season: "",
    });
  };

  const handleLike = async (recipeId) => {
    if (!user) {
      alert("Veuillez vous connecter pour aimer une recette");
      return;
    }

    try {
      await api.post(`/recipes/${recipeId}/like`, { userId: user._id });
      fetchRecipes();
    } catch (error) {
      console.error("Error liking recipe:", error);
    }
  };

  return (
    <div className="min-h-screen bg-dark-950 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">
              Recettes locales
            </h1>
            <p className="text-dark-300">
              Découvrez des recettes créées avec des ingrédients locaux
            </p>
          </div>
          {user && (
            <Link
              to="/recipes/add"
              className="btn-primary flex items-center mt-4 md:mt-0"
            >
              <Plus className="w-5 h-5 mr-2" />
              Ajouter une recette
            </Link>
          )}
        </div>

        {/* Search and Filters */}
        <div className="mb-8">
          <div className="flex flex-col md:flex-row gap-4 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-dark-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Rechercher une recette..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="input pl-10 w-full"
              />
            </div>
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="btn-secondary flex items-center"
            >
              <Filter className="w-5 h-5 mr-2" />
              Filtres
            </button>
          </div>

          {/* Filters Panel */}
          {showFilters && (
            <div className="card p-6 mb-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div>
                  <label className="block text-sm font-medium text-dark-300 mb-2">
                    Catégorie
                  </label>
                  <select
                    value={filters.category}
                    onChange={(e) =>
                      handleFilterChange("category", e.target.value)
                    }
                    className="input w-full"
                  >
                    <option value="">Toutes les catégories</option>
                    {categories.map((category) => (
                      <option key={category} value={category}>
                        {category}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-300 mb-2">
                    Difficulté
                  </label>
                  <select
                    value={filters.difficulty}
                    onChange={(e) =>
                      handleFilterChange("difficulty", e.target.value)
                    }
                    className="input w-full"
                  >
                    <option value="">Toutes les difficultés</option>
                    {difficulties.map((difficulty) => (
                      <option key={difficulty} value={difficulty}>
                        {difficulty}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-300 mb-2">
                    Saison
                  </label>
                  <select
                    value={filters.season}
                    onChange={(e) =>
                      handleFilterChange("season", e.target.value)
                    }
                    className="input w-full"
                  >
                    <option value="">Toutes les saisons</option>
                    {seasons.map((season) => (
                      <option key={season} value={season}>
                        {season}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <button
                onClick={clearFilters}
                className="text-primary-400 hover:text-primary-300 text-sm"
              >
                Effacer les filtres
              </button>
            </div>
          )}
        </div>

        {/* Results Count */}
        <div className="mb-6">
          <p className="text-dark-300">
            {filteredRecipes.length} recette
            {filteredRecipes.length > 1 ? "s" : ""} trouvée
            {filteredRecipes.length > 1 ? "s" : ""}
          </p>
        </div>

        {/* Recipes Grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[...Array(6)].map((_, i) => (
              <div
                key={i}
                className="card h-80 animate-pulse bg-dark-800"
              ></div>
            ))}
          </div>
        ) : filteredRecipes.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-dark-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-dark-600" />
            </div>
            <h3 className="text-xl font-semibold text-white mb-2">
              Aucune recette trouvée
            </h3>
            <p className="text-dark-300">
              Essayez de modifier vos critères de recherche
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRecipes.map((recipe) => (
              <RecipeCard
                key={recipe._id}
                recipe={recipe}
                onLike={handleLike}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default Recipes;
