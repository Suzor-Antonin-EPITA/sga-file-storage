import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Trash2, Plus, Minus, ShoppingBag, ArrowLeft } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';

const Cart = () => {
  const { cartItems, updateQuantity, removeFromCart, getTotalPrice, clearCart } = useCart();
  const { user } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [orderForm, setOrderForm] = useState({
    deliveryAddress: '',
    deliveryDate: '',
    paymentMethod: 'card',
    notes: ''
  });

  const handleQuantityChange = async (itemId, newQuantity) => {
    if (newQuantity <= 0) {
      await removeFromCart(itemId);
    } else {
      await updateQuantity(itemId, newQuantity);
    }
  };

  const handleOrderSubmit = async (e) => {
    e.preventDefault();
    if (!user || cartItems.length === 0) return;

    try {
      setLoading(true);
      
      const orderData = {
        user: user.username,
        items: cartItems.map(item => ({
          productId: item.productId,
          productType: item.productType,
          name: item.name || item.title,
          price: item.productType === 'surplus' ? item.discountedPrice : item.price,
          quantity: item.quantity,
          image: item.image
        })),
        totalAmount: getTotalPrice(),
        ...orderForm
      };

      await api.post('/orders', orderData);
      clearCart();
      navigate('/profile', { state: { tab: 'orders' } });
    } catch (error) {
      console.error('Error creating order:', error);
      alert('Erreur lors de la commande');
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-dark-950 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Connexion requise</h1>
          <p className="text-dark-300 mb-6">Vous devez être connecté pour accéder au panier.</p>
          <Link to="/" className="btn-primary">
            Retour à l'accueil
          </Link>
        </div>
      </div>
    );
  }

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-dark-950 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center py-16">
            <div className="w-16 h-16 bg-dark-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <ShoppingBag className="w-8 h-8 text-dark-600" />
            </div>
            <h1 className="text-2xl font-bold text-white mb-4">Votre panier est vide</h1>
            <p className="text-dark-300 mb-8">Découvrez nos produits locaux et surplus alimentaires</p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/marketplace" className="btn-primary">
                Explorer le marketplace
              </Link>
              <Link to="/surplus" className="btn-secondary">
                Voir les surplus
              </Link>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-950 py-8">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center mb-8">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center text-dark-300 hover:text-white transition-colors mr-4"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Retour
          </button>
          <h1 className="text-3xl font-bold text-white">Mon panier</h1>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <div className="card p-6">
              <h2 className="text-xl font-semibold text-white mb-6">
                Articles ({cartItems.length})
              </h2>
              
              <div className="space-y-4">
                {cartItems.map((item) => (
                  <div key={item._id} className="flex items-center space-x-4 p-4 bg-dark-800 rounded-lg">
                    <img
                      src={item.image}
                      alt={item.name || item.title}
                      className="w-16 h-16 object-cover rounded-lg"
                    />
                    
                    <div className="flex-1">
                      <h3 className="font-medium text-white">
                        {item.name || item.title}
                      </h3>
                      <p className="text-sm text-dark-300">
                        {item.productType === 'surplus' ? 'Surplus' : 'Produit'} • {item.seller}
                      </p>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className="text-lg font-semibold text-white">
                          {item.productType === 'surplus' ? item.discountedPrice : item.price}€
                        </span>
                        {item.productType === 'surplus' && (
                          <span className="text-sm text-dark-400 line-through">
                            {item.originalPrice}€
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Quantity Controls */}
                    <div className="flex items-center space-x-2">
                      <button
                        onClick={() => handleQuantityChange(item._id, item.quantity - 1)}
                        className="p-1 text-dark-400 hover:text-white transition-colors"
                      >
                        <Minus className="w-4 h-4" />
                      </button>
                      <span className="w-8 text-center text-white">{item.quantity}</span>
                      <button
                        onClick={() => handleQuantityChange(item._id, item.quantity + 1)}
                        className="p-1 text-dark-400 hover:text-white transition-colors"
                      >
                        <Plus className="w-4 h-4" />
                      </button>
                    </div>

                    <button
                      onClick={() => removeFromCart(item._id)}
                      className="p-2 text-red-400 hover:text-red-300 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Order Summary & Checkout */}
          <div className="lg:col-span-1">
            <div className="card p-6 sticky top-8">
              <h2 className="text-xl font-semibold text-white mb-6">Récapitulatif</h2>
              
              <div className="space-y-3 mb-6">
                <div className="flex justify-between text-dark-300">
                  <span>Sous-total</span>
                  <span>{getTotalPrice().toFixed(2)}€</span>
                </div>
                <div className="flex justify-between text-dark-300">
                  <span>Livraison</span>
                  <span>Gratuite</span>
                </div>
                <div className="border-t border-dark-800 pt-3">
                  <div className="flex justify-between text-lg font-semibold text-white">
                    <span>Total</span>
                    <span>{getTotalPrice().toFixed(2)}€</span>
                  </div>
                </div>
              </div>

              {/* Order Form */}
              <form onSubmit={handleOrderSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-dark-300 mb-2">
                    Adresse de livraison *
                  </label>
                  <textarea
                    value={orderForm.deliveryAddress}
                    onChange={(e) => setOrderForm(prev => ({ ...prev, deliveryAddress: e.target.value }))}
                    className="input w-full"
                    rows={3}
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-dark-300 mb-2">
                    Date de livraison souhaitée
                  </label>
                  <input
                    type="date"
                    value={orderForm.deliveryDate}
                    onChange={(e) => setOrderForm(prev => ({ ...prev, deliveryDate: e.target.value }))}
                    className="input w-full"
                    min={new Date().toISOString().split('T')[0]}
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-dark-300 mb-2">
                    Mode de paiement *
                  </label>
                  <select
                    value={orderForm.paymentMethod}
                    onChange={(e) => setOrderForm(prev => ({ ...prev, paymentMethod: e.target.value }))}
                    className="input w-full"
                    required
                  >
                    <option value="card">Carte bancaire</option>
                    <option value="paypal">PayPal</option>
                    <option value="cash">Espèces à la livraison</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-dark-300 mb-2">
                    Notes (optionnel)
                  </label>
                  <textarea
                    value={orderForm.notes}
                    onChange={(e) => setOrderForm(prev => ({ ...prev, notes: e.target.value }))}
                    className="input w-full"
                    rows={2}
                    placeholder="Instructions particulières..."
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading || !orderForm.deliveryAddress}
                  className="btn-primary w-full disabled:opacity-50"
                >
                  {loading ? 'Commande en cours...' : 'Finaliser la commande'}
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
