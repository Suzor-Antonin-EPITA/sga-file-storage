import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { Heart, Clock, Users, Edit, Trash2, MessageCircle, Send, ArrowLeft } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';

const RecipeDetail = () => {
  const [recipe, setRecipe] = useState(null);
  const [loading, setLoading] = useState(true);
  const [isLiked, setIsLiked] = useState(false);
  const [comment, setComment] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);
  const { id } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    fetchRecipe();
  }, [id]);

  const fetchRecipe = async () => {
    try {
      const response = await api.get(`/recipes/${id}`);
      setRecipe(response.data);
      if (user) {
        setIsLiked(response.data.likedBy.includes(user._id));
      }
    } catch (error) {
      console.error('Error fetching recipe:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLike = async () => {
    if (!user) return;

    try {
      const response = await api.post(`/recipes/${id}/like`, {
        userId: user._id
      });
      setRecipe(response.data);
      setIsLiked(response.data.likedBy.includes(user._id));
    } catch (error) {
      console.error('Error liking recipe:', error);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm('Êtes-vous sûr de vouloir supprimer cette recette ?')) {
      return;
    }

    try {
      await api.delete(`/recipes/${id}`);
      navigate('/recipes');
    } catch (error) {
      console.error('Error deleting recipe:', error);
    }
  };

  const handleCommentSubmit = async (e) => {
    e.preventDefault();
    if (!user || !comment.trim()) return;

    try {
      setSubmittingComment(true);
      const response = await api.post(`/recipes/${id}/comments`, {
        user: user.username,
        text: comment.trim()
      });
      setRecipe(response.data);
      setComment('');
    } catch (error) {
      console.error('Error adding comment:', error);
    } finally {
      setSubmittingComment(false);
    }
  };

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'Facile': return 'text-green-400 bg-green-400/10';
      case 'Moyen': return 'text-yellow-400 bg-yellow-400/10';
      case 'Difficile': return 'text-red-400 bg-red-400/10';
      default: return 'text-dark-300 bg-dark-800';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-dark-950 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse">
            <div className="h-8 bg-dark-800 rounded w-1/4 mb-4"></div>
            <div className="h-64 bg-dark-800 rounded-xl mb-6"></div>
            <div className="h-6 bg-dark-800 rounded w-3/4 mb-4"></div>
            <div className="h-4 bg-dark-800 rounded w-1/2"></div>
          </div>
        </div>
      </div>
    );
  }

  if (!recipe) {
    return (
      <div className="min-h-screen bg-dark-950 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Recette non trouvée</h1>
          <Link to="/recipes" className="btn-primary">
            Retour aux recettes
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-950 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <button
            onClick={() => navigate('/recipes')}
            className="flex items-center text-dark-300 hover:text-white transition-colors"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Retour aux recettes
          </button>
          
          {user && user.username === recipe.author && (
            <div className="flex items-center space-x-2">
              <Link
                to={`/recipes/edit/${recipe._id}`}
                className="btn-secondary flex items-center"
              >
                <Edit className="w-4 h-4 mr-2" />
                Modifier
              </Link>
              <button
                onClick={handleDelete}
                className="p-2 text-red-400 hover:text-red-300 transition-colors"
              >
                <Trash2 className="w-5 h-5" />
              </button>
            </div>
          )}
        </div>

        {/* Recipe Card */}
        <div className="card overflow-hidden">
          <img
            src={recipe.image}
            alt={recipe.title}
            className="w-full h-64 md:h-80 object-cover"
          />
          
          <div className="p-8">
            {/* Title and Meta */}
            <div className="flex flex-wrap items-start justify-between mb-6">
              <div className="flex-1 min-w-0">
                <h1 className="text-3xl font-bold text-white mb-2">{recipe.title}</h1>
                <p className="text-dark-300 text-lg">{recipe.description}</p>
              </div>
              
              <div className="flex flex-wrap gap-2 mt-2 md:mt-0">
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getDifficultyColor(recipe.difficulty)}`}>
                  {recipe.difficulty}
                </span>
                {recipe.localIngredients && (
                  <span className="px-3 py-1 rounded-full text-sm font-medium bg-green-600 text-white">
                    Local
                  </span>
                )}
              </div>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap items-center gap-6 mb-8 text-dark-300">
              <div className="flex items-center">
                <Clock className="w-5 h-5 mr-2" />
                {recipe.cookingTime} minutes
              </div>
              <div className="flex items-center">
                <Users className="w-5 h-5 mr-2" />
                Par {recipe.author}
              </div>
              <div className="text-sm">
                {recipe.category} • {recipe.season}
              </div>
            </div>

            {/* Actions */}
            <div className="flex items-center justify-between mb-8 pb-8 border-b border-dark-800">
              <div className="flex items-center space-x-6">
                <button
                  onClick={handleLike}
                  disabled={!user}
                  className={`flex items-center space-x-2 transition-colors ${
                    isLiked ? 'text-red-400' : 'text-dark-400 hover:text-red-400'
                  }`}
                >
                  <Heart className={`w-5 h-5 ${isLiked ? 'fill-current' : ''}`} />
                  <span>{recipe.likes} J'aime</span>
                </button>
                <div className="flex items-center space-x-2 text-dark-400">
                  <MessageCircle className="w-5 h-5" />
                  <span>{recipe.comments?.length || 0} Commentaires</span>
                </div>
              </div>
            </div>

            {/* Ingredients and Instructions */}
            <div className="grid md:grid-cols-2 gap-8 mb-8">
              <div>
                <h2 className="text-xl font-semibold text-white mb-4">Ingrédients</h2>
                <ul className="space-y-2">
                  {recipe.ingredients.map((ingredient, index) => (
                    <li key={index} className="flex items-start">
                      <span className="w-2 h-2 bg-primary-600 rounded-full mt-2 mr-3 flex-shrink-0"></span>
                      <span className="text-dark-300">{ingredient}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h2 className="text-xl font-semibold text-white mb-4">Instructions</h2>
                <ol className="space-y-4">
                  {recipe.instructions.map((instruction, index) => (
                    <li key={index} className="flex items-start">
                      <span className="w-6 h-6 bg-primary-600 text-white rounded-full flex items-center justify-center text-sm font-medium mr-3 flex-shrink-0 mt-0.5">
                        {index + 1}
                      </span>
                      <span className="text-dark-300">{instruction}</span>
                    </li>
                  ))}
                </ol>
              </div>
            </div>

            {/* Comments */}
            <div>
              <h2 className="text-xl font-semibold text-white mb-4">
                Commentaires ({recipe.comments?.length || 0})
              </h2>

              {/* Add Comment */}
              {user ? (
                <form onSubmit={handleCommentSubmit} className="mb-6">
                  <div className="flex gap-3">
                    <textarea
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                      placeholder="Ajoutez un commentaire..."
                      className="input flex-1"
                      rows={3}
                    />
                    <button
                      type="submit"
                      disabled={!comment.trim() || submittingComment}
                      className="btn-primary h-fit disabled:opacity-50"
                    >
                      <Send className="w-4 h-4" />
                    </button>
                  </div>
                </form>
              ) : (
                <p className="text-dark-400 mb-6">
                  Connectez-vous pour laisser un commentaire
                </p>
              )}

              {/* Comments List */}
              <div className="space-y-4">
                {recipe.comments?.map((comment, index) => (
                  <div key={index} className="bg-dark-800 rounded-lg p-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="font-medium text-white">{comment.user}</span>
                      <span className="text-sm text-dark-400">
                        {new Date(comment.createdAt).toLocaleDateString('fr-FR')}
                      </span>
                    </div>
                    <p className="text-dark-300">{comment.text}</p>
                  </div>
                ))}
                
                {(!recipe.comments || recipe.comments.length === 0) && (
                  <p className="text-dark-400 text-center py-8">
                    Aucun commentaire pour le moment
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecipeDetail;
