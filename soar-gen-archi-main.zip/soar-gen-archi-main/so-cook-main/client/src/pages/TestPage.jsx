import React, { useState, useEffect } from 'react';
import { CheckCircle, XCircle, AlertCircle, Loader } from 'lucide-react';
import api from '../services/api';

const TestPage = () => {
  const [tests, setTests] = useState([
    { name: 'Connexion API', status: 'pending', message: '' },
    { name: 'Récupération des recettes', status: 'pending', message: '' },
    { name: 'Création d\'une recette test', status: 'pending', message: '' },
    { name: 'Récupération des produits', status: 'pending', message: '' },
    { name: 'Récupération des surplus', status: 'pending', message: '' },
    { name: 'Test MongoDB', status: 'pending', message: '' }
  ]);

  const updateTest = (index, status, message = '') => {
    setTests(prev => prev.map((test, i) => 
      i === index ? { ...test, status, message } : test
    ));
  };

  const runTests = async () => {
    // Reset tous les tests
    setTests(prev => prev.map(test => ({ ...test, status: 'pending', message: '' })));

    // Test 1: Connexion API
    try {
      console.log('Testing API connection...');
      const response = await api.get('/');
      console.log('API Response:', response.data);
      updateTest(0, 'success', `✅ ${response.data.message}`);
    } catch (error) {
      console.error('API Error:', error);
      updateTest(0, 'error', `❌ Erreur de connexion: ${error.response?.status || error.message}`);
      return; // Stop tests if API is not reachable
    }

    // Test 2: Récupération des recettes
    try {
      console.log('Testing recipes endpoint...');
      const response = await api.get('/recipes');
      console.log('Recipes Response:', response.data);
      updateTest(1, 'success', `✅ ${response.data.length} recettes récupérées`);
    } catch (error) {
      console.error('Recipes Error:', error);
      updateTest(1, 'error', `❌ Erreur recettes: ${error.response?.status || error.message}`);
    }

    // Test 3: Création d'une recette test
    try {
      console.log('Testing recipe creation...');
      const testRecipe = {
        title: 'Recette Test - ' + Date.now(),
        description: 'Une recette créée pour tester l\'API',
        ingredients: ['Ingrédient 1', 'Ingrédient 2'],
        instructions: ['Étape 1', 'Étape 2'],
        cookingTime: 15,
        difficulty: 'Facile',
        category: 'Test',
        author: 'TestBot',
        season: 'Toute saison'
      };
      
      const response = await api.post('/recipes', testRecipe);
      console.log('Recipe Creation Response:', response.data);
      updateTest(2, 'success', `✅ Recette créée avec ID: ${response.data._id}`);
      
      // Nettoyer - supprimer la recette test
      await api.delete(`/recipes/${response.data._id}`);
      console.log('Test recipe deleted');
    } catch (error) {
      console.error('Recipe Creation Error:', error);
      updateTest(2, 'error', `❌ Erreur création: ${error.response?.data?.error || error.message}`);
    }

    // Test 4: Récupération des produits
    try {
      console.log('Testing products endpoint...');
      const response = await api.get('/products');
      console.log('Products Response:', response.data);
      updateTest(3, 'success', `✅ ${response.data.length} produits récupérés`);
    } catch (error) {
      console.error('Products Error:', error);
      updateTest(3, 'error', `❌ Erreur produits: ${error.response?.status || error.message}`);
    }

    // Test 5: Récupération des surplus
    try {
      console.log('Testing surplus endpoint...');
      const response = await api.get('/surplus');
      console.log('Surplus Response:', response.data);
      updateTest(4, 'success', `✅ ${response.data.length} surplus récupérés`);
    } catch (error) {
      console.error('Surplus Error:', error);
      updateTest(4, 'error', `❌ Erreur surplus: ${error.response?.status || error.message}`);
    }

    // Test 6: Test MongoDB indirect
    try {
      console.log('Testing MongoDB connection via API...');
      const recipesResponse = await api.get('/recipes');
      const productsResponse = await api.get('/products');
      const surplusResponse = await api.get('/surplus');
      
      updateTest(5, 'success', `✅ MongoDB fonctionne - Collections accessibles`);
    } catch (error) {
      console.error('MongoDB Error:', error);
      updateTest(5, 'error', `❌ Problème MongoDB: ${error.message}`);
    }
  };

  // Auto-run tests on component mount
  useEffect(() => {
    setTimeout(() => {
      runTests();
    }, 1000);
  }, []);

  const createSampleData = async () => {
    try {
      console.log('Creating sample data...');
      
      // Créer quelques recettes d'exemple
      const sampleRecipes = [
        {
          title: 'Ratatouille Parisienne',
          description: 'Un classique français avec des légumes locaux du 18ème arrondissement',
          ingredients: ['Aubergines', 'Courgettes', 'Tomates', 'Poivrons', 'Oignons', 'Ail', 'Herbes de Provence'],
          instructions: [
            'Couper tous les légumes en dés',
            'Faire revenir les oignons et l\'ail',
            'Ajouter les légumes progressivement',
            'Laisser mijoter 45 minutes',
            'Assaisonner avec les herbes'
          ],
          cookingTime: 60,
          difficulty: 'Moyen',
          category: 'Plat principal',
          author: 'Marie Dubois',
          season: 'Été',
          localIngredients: true
        },
        {
          title: 'Salade de Roquette du Marais',
          description: 'Salade fraîche avec de la roquette cultivée dans les jardins partagés',
          ingredients: ['Roquette', 'Tomates cerises', 'Mozzarella', 'Huile d\'olive', 'Vinaigre balsamique'],
          instructions: [
            'Laver la roquette',
            'Couper les tomates en deux',
            'Disposer dans un saladier',
            'Ajouter la mozzarella',
            'Assaisonner'
          ],
          cookingTime: 5,
          difficulty: 'Facile',
          category: 'Entrée',
          author: 'Pierre Martin',
          season: 'Printemps',
          localIngredients: true
        }
      ];

      for (const recipe of sampleRecipes) {
        await api.post('/recipes', recipe);
      }

      // Créer quelques produits d'exemple
      const sampleProducts = [
        {
          name: 'Tomates Bio du 19ème',
          description: 'Tomates cultivées dans les jardins urbains du 19ème arrondissement',
          price: 4.50,
          unit: 'kg',
          category: 'Légumes',
          seller: 'Jardin Partagé Crimée',
          location: 'Paris 19ème',
          availability: 25,
          organic: true,
          local: true,
          harvestDate: new Date()
        },
        {
          name: 'Basilic Frais Local',
          description: 'Basilic cultivé sur les toits de Belleville',
          price: 2.00,
          unit: 'bouquet',
          category: 'Herbes',
          seller: 'Ferme Urbaine Belleville',
          location: 'Paris 20ème',
          availability: 15,
          organic: true,
          local: true,
          harvestDate: new Date()
        }
      ];

      for (const product of sampleProducts) {
        await api.post('/products', product);
      }

      // Créer quelques surplus d'exemple
      const sampleSurplus = [
        {
          title: 'Panier de légumes invendus',
          description: 'Mix de légumes frais de saison légèrement abîmés mais parfaits pour cuisiner',
          items: ['Carottes', 'Poireaux', 'Pommes de terre', 'Navets'],
          originalPrice: 12.00,
          discountedPrice: 4.00,
          seller: 'Marché des Enfants Rouges',
          location: 'Paris 3ème',
          availableQuantity: 5,
          pickupTimeStart: '18h00',
          pickupTimeEnd: '20h00',
          expiryDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000), // Dans 2 jours
          category: 'Légumes'
        }
      ];

      for (const surplus of sampleSurplus) {
        await api.post('/surplus', surplus);
      }

      alert('Données d\'exemple créées avec succès !');
      console.log('Sample data created successfully');
      
    } catch (error) {
      console.error('Error creating sample data:', error);
      alert('Erreur lors de la création des données: ' + error.message);
    }
  };

  // Test d'authentification
  const testAuthentication = async () => {
    try {
      console.log('Testing authentication...');
      
      // Test de création d'utilisateur
      const testUser = {
        username: 'testuser_' + Date.now(),
        email: `test_${Date.now()}@example.com`,
        password: 'testpassword123',
        location: 'Paris Test',
        bio: 'Utilisateur de test créé automatiquement'
      };

      const registerResponse = await api.post('/users/register', testUser);
      console.log('Register Response:', registerResponse.data);
      
      // Test de connexion
      const loginResponse = await api.post('/users/login', {
        email: testUser.email,
        password: testUser.password
      });
      console.log('Login Response:', loginResponse.data);
      
      alert(`✅ Authentification réussie! Utilisateur créé: ${testUser.username}`);
    } catch (error) {
      console.error('Authentication Error:', error);
      alert(`❌ Erreur d'authentification: ${error.response?.data?.error || error.message}`);
    }
  };

  // Test du système de panier
  const testCartSystem = async () => {
    try {
      console.log('Testing cart system...');
      
      // D'abord, récupérer un produit existant ou en créer un
      let productsResponse = await api.get('/products');
      let productId;
      
      if (productsResponse.data.length === 0) {
        // Créer un produit de test
        const testProduct = {
          name: 'Produit Test Panier',
          description: 'Produit créé pour tester le panier',
          price: 5.99,
          unit: 'pièce',
          category: 'Test',
          seller: 'Test Seller',
          location: 'Test Location',
          availability: 10,
          organic: false,
          local: true
        };
        const createResponse = await api.post('/products', testProduct);
        productId = createResponse.data._id;
      } else {
        productId = productsResponse.data[0]._id;
      }

      // Créer un utilisateur test pour le panier
      const testUser = {
        username: 'cartuser_' + Date.now(),
        email: `carttest_${Date.now()}@example.com`,
        password: 'testpassword123'
      };
      
      const userResponse = await api.post('/users/register', testUser);
      const userId = userResponse.data.user._id;
      
      // Ajouter au panier
      const cartItem = {
        productId: productId,
        productType: 'product',
        quantity: 2
      };
      
      const cartResponse = await api.post(`/users/${userId}/cart`, cartItem);
      console.log('Cart Response:', cartResponse.data);
      
      alert(`✅ Test panier réussi! Produit ajouté au panier de l'utilisateur ${testUser.username}`);
    } catch (error) {
      console.error('Cart Error:', error);
      alert(`❌ Erreur panier: ${error.response?.data?.error || error.message}`);
    }
  };

  // Test d'ajout de commentaire sur recette
  const testRecipeComment = async () => {
    try {
      console.log('Testing recipe comments...');
      
      let recipesResponse = await api.get('/recipes');
      let recipeId;
      
      if (recipesResponse.data.length === 0) {
        const testRecipe = {
          title: 'Recette Test Commentaire',
          description: 'Recette créée pour tester les commentaires',
          ingredients: ['Ingrédient test'],
          instructions: ['Instruction test'],
          cookingTime: 10,
          difficulty: 'Facile',
          category: 'Test',
          author: 'TestBot',
          season: 'Toute saison'
        };
        const createResponse = await api.post('/recipes', testRecipe);
        recipeId = createResponse.data._id;
      } else {
        recipeId = recipesResponse.data[0]._id;
      }

      // Ajouter un commentaire
      const testComment = {
        user: 'TestUser_' + Date.now(),
        text: 'Excellent! Cette recette est vraiment délicieuse. Je la recommande vivement!'
      };
      
      const commentResponse = await api.post(`/recipes/${recipeId}/comments`, testComment);
      console.log('Comment Response:', commentResponse.data);
      
      alert(`✅ Commentaire ajouté avec succès sur la recette!`);
    } catch (error) {
      console.error('Comment Error:', error);
      alert(`❌ Erreur commentaire: ${error.response?.data?.error || error.message}`);
    }
  };



  const getStatusIcon = (status) => {
    switch (status) {
      case 'success': return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'error': return <XCircle className="w-5 h-5 text-red-400" />;
      case 'pending': return <Loader className="w-5 h-5 text-yellow-400 animate-spin" />;
      default: return <AlertCircle className="w-5 h-5 text-gray-400" />;
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-white mb-4">🧪 Page de Test - So-Cook</h1>
        <p className="text-dark-300">
          Utilisez cette page pour vérifier que le frontend, backend et la base de données fonctionnent correctement ensemble.
        </p>
      </div>

      {/* Debug Info */}
      <div className="card p-4 mb-6 bg-dark-800">
        <h3 className="text-lg font-semibold text-white mb-2">🔍 Debug Info</h3>
        <div className="text-sm text-dark-300 space-y-1">
          <div>Frontend URL: {window.location.origin}</div>
          <div>API Base URL: /api (proxied to localhost:5002)</div>
          <div>Ouvrez la console pour voir les logs détaillés</div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {/* Tests de connexion */}
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-white mb-4">Tests de Connexion</h2>
          
          <div className="space-y-3 mb-6">
            {tests.map((test, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-dark-800 rounded-lg">
                <span className="text-dark-300">{test.name}</span>
                {getStatusIcon(test.status)}
              </div>
            ))}
          </div>

          <button
            onClick={runTests}
            className="btn-primary w-full"
          >
            🚀 Relancer les Tests
          </button>
        </div>

        {/* Résultats des tests */}
        <div className="card p-6">
          <h2 className="text-xl font-semibold text-white mb-4">Résultats des Tests</h2>
          
          <div className="space-y-2 mb-6 max-h-64 overflow-y-auto">
            {tests.map((test, index) => (
              test.message && (
                <div key={index} className="text-sm p-2 bg-dark-800 rounded">
                  <div className="font-medium text-white">{test.name}</div>
                  <div className="text-dark-300">{test.message}</div>
                </div>
              )
            ))}
          </div>

          <button
            onClick={createSampleData}
            className="btn-secondary w-full"
          >
            📊 Créer des Données d'Exemple
          </button>
        </div>
      </div>

      {/* Nouveaux Tests Fonctionnels */}
      <div className="mt-6">
        <h2 className="text-2xl font-semibold text-white mb-6">🧪 Tests Fonctionnels</h2>
        
        <div className="grid md:grid-cols-3 gap-4">
          {/* Tests d'authentification */}
          <div className="card p-4">
            <h3 className="text-lg font-semibold text-white mb-3">👤 Authentification</h3>
            <p className="text-dark-300 text-sm mb-4">
              Test la création d'utilisateur et la connexion
            </p>
            <button
              onClick={testAuthentication}
              className="btn-primary w-full text-sm"
            >
              🔐 Tester Inscription/Connexion
            </button>
          </div>

          {/* Tests du panier */}
          <div className="card p-4">
            <h3 className="text-lg font-semibold text-white mb-3">🛒 Système de Panier</h3>
            <p className="text-dark-300 text-sm mb-4">
              Test l'ajout de produits au panier utilisateur
            </p>
            <button
              onClick={testCartSystem}
              className="btn-primary w-full text-sm"
            >
              🛍️ Tester Ajout au Panier
            </button>
          </div>

          {/* Tests des commentaires */}
          <div className="card p-4">
            <h3 className="text-lg font-semibold text-white mb-3">💬 Commentaires</h3>
            <p className="text-dark-300 text-sm mb-4">
              Test l'ajout de commentaires sur les recettes
            </p>
            <button
              onClick={testRecipeComment}
              className="btn-primary w-full text-sm"
            >
              📝 Tester Commentaires
            </button>
          </div>
        </div>

        {/* Test complet */}
        <div className="mt-6 card p-6 bg-gradient-to-r from-primary-900 to-primary-800">
          <h3 className="text-xl font-semibold text-white mb-3">🎯 Test Suite Complète</h3>
          <p className="text-primary-100 mb-4">
            Lance les 3 tests fonctionnels en séquence pour valider les fonctionnalités principales
          </p>
          <button
            onClick={async () => {
              console.log('Running complete test suite...');
              await testAuthentication();
              await new Promise(resolve => setTimeout(resolve, 1000));
              await testCartSystem();
              await new Promise(resolve => setTimeout(resolve, 1000));
              await testRecipeComment();
              alert('✅ Suite de tests complète terminée! Consultez la console pour les détails.');
            }}
            className="btn-secondary"
          >
            🚀 Lancer Suite Complète
          </button>
        </div>
      </div>

      {/* Informations système */}
      <div className="card p-6 mt-6">
        <h2 className="text-xl font-semibold text-white mb-4">ℹ️ Informations Système</h2>
        <div className="grid md:grid-cols-3 gap-4 text-sm">
          <div>
            <div className="text-dark-400">Frontend</div>
            <div className="text-white">React + Vite (Port 3000)</div>
          </div>
          <div>
            <div className="text-dark-400">Backend</div>
            <div className="text-white">Express.js (Port 5002)</div>
          </div>
          <div>
            <div className="text-dark-400">Base de données</div>
            <div className="text-white">MongoDB (Port 27017)</div>
          </div>
        </div>
      </div>

      {/* Instructions */}
      <div className="card p-6 mt-6">
        <h2 className="text-xl font-semibold text-white mb-4">📋 Instructions</h2>
        <div className="space-y-3 text-sm text-dark-300">
          <div>
            <strong className="text-white">1. Tests de connexion :</strong> Cliquez sur "Relancer les Tests" pour vérifier tous les services
          </div>
          <div>
            <strong className="text-white">2. Données d'exemple :</strong> Cliquez sur "Créer des Données d'Exemple" pour remplir la base avec du contenu de test
          </div>
          <div>
            <strong className="text-white">3. Tests fonctionnels :</strong> Testez l'authentification, le panier et les commentaires
          </div>
          <div>
            <strong className="text-white">4. Suite complète :</strong> Le bouton "Lancer Suite Complète" exécute les 3 tests principaux en séquence
          </div>
          <div>
            <strong className="text-white">5. Navigation :</strong> Une fois les tests passés, explorez les autres pages (Recettes, Marketplace, Surplus)
          </div>
          <div>
            <strong className="text-white">6. Console :</strong> Ouvrez les outils de développement pour voir les logs détaillés de chaque test
          </div>
        </div>
      </div>
    </div>
  );
};

export default TestPage;
