import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import { User, Package, Heart, Settings, Clock, CheckCircle, XCircle } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';

const Profile = () => {
  const [activeTab, setActiveTab] = useState('profile');
  const [orders, setOrders] = useState([]);
  const [favoriteRecipes, setFavoriteRecipes] = useState([]);
  const [loading, setLoading] = useState(false);
  const { user, logout } = useAuth();
  const location = useLocation();

  useEffect(() => {
    if (location.state?.tab) {
      setActiveTab(location.state.tab);
    }
  }, [location.state]);

  useEffect(() => {
    if (user && activeTab === 'orders') {
      fetchOrders();
    }
  }, [user, activeTab]);

  const fetchOrders = async () => {
    try {
      setLoading(true);
      const response = await api.get(`/orders/user/${user._id}`);
      setOrders(response.data);
    } catch (error) {
      console.error('Error fetching orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'pending': return 'text-yellow-400';
      case 'confirmed': return 'text-blue-400';
      case 'preparing': return 'text-orange-400';
      case 'ready': return 'text-purple-400';
      case 'completed': return 'text-green-400';
      case 'cancelled': return 'text-red-400';
      default: return 'text-dark-300';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed': return CheckCircle;
      case 'cancelled': return XCircle;
      default: return Clock;
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'pending': return 'En attente';
      case 'confirmed': return 'Confirmée';
      case 'preparing': return 'En préparation';
      case 'ready': return 'Prête';
      case 'completed': return 'Terminée';
      case 'cancelled': return 'Annulée';
      default: return status;
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-dark-950 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Connexion requise</h1>
          <p className="text-dark-300">Vous devez être connecté pour accéder à votre profil.</p>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'profile', label: 'Profil', icon: User },
    { id: 'orders', label: 'Mes commandes', icon: Package },
    { id: 'favorites', label: 'Favoris', icon: Heart },
    { id: 'settings', label: 'Paramètres', icon: Settings }
  ];

  return (
    <div className="min-h-screen bg-dark-950 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Mon profil</h1>
          <p className="text-dark-300">Gérez votre compte et vos commandes</p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <div className="card p-6">
              <div className="text-center mb-6">
                <img
                  src={user.avatar}
                  alt={user.username}
                  className="w-20 h-20 rounded-full mx-auto mb-3"
                />
                <h2 className="text-xl font-semibold text-white">{user.username}</h2>
                <p className="text-dark-300">{user.email}</p>
              </div>

              <nav className="space-y-2">
                {tabs.map(tab => {
                  const Icon = tab.icon;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveTab(tab.id)}
                      className={`w-full flex items-center px-4 py-3 rounded-lg text-left transition-colors ${
                        activeTab === tab.id
                          ? 'bg-primary-600 text-white'
                          : 'text-dark-300 hover:bg-dark-800 hover:text-white'
                      }`}
                    >
                      <Icon className="w-5 h-5 mr-3" />
                      {tab.label}
                    </button>
                  );
                })}
              </nav>
            </div>
          </div>

          {/* Content */}
          <div className="lg:col-span-3">
            <div className="card p-8">
              {activeTab === 'profile' && (
                <div>
                  <h2 className="text-2xl font-semibold text-white mb-6">Informations personnelles</h2>
                  <div className="grid md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-dark-300 mb-2">
                        Nom d'utilisateur
                      </label>
                      <input
                        type="text"
                        value={user.username}
                        className="input w-full"
                        readOnly
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-dark-300 mb-2">
                        Email
                      </label>
                      <input
                        type="email"
                        value={user.email}
                        className="input w-full"
                        readOnly
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-dark-300 mb-2">
                        Localisation
                      </label>
                      <input
                        type="text"
                        value={user.location || ''}
                        placeholder="Votre ville"
                        className="input w-full"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-dark-300 mb-2">
                        Type de compte
                      </label>
                      <div className="flex items-center">
                        <input
                          type="checkbox"
                          checked={user.isProducer}
                          className="rounded border-dark-600 bg-dark-800 text-primary-600 focus:ring-primary-500"
                          readOnly
                        />
                        <label className="ml-2 text-sm text-dark-300">
                          Je suis producteur
                        </label>
                      </div>
                    </div>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-medium text-dark-300 mb-2">
                        Bio
                      </label>
                      <textarea
                        value={user.bio || ''}
                        placeholder="Parlez-nous de vous..."
                        className="input w-full"
                        rows={4}
                      />
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'orders' && (
                <div>
                  <h2 className="text-2xl font-semibold text-white mb-6">Mes commandes</h2>
                  {loading ? (
                    <div className="space-y-4">
                      {[...Array(3)].map((_, i) => (
                        <div key={i} className="h-24 bg-dark-800 rounded-lg animate-pulse"></div>
                      ))}
                    </div>
                  ) : orders.length === 0 ? (
                    <div className="text-center py-12">
                      <Package className="w-16 h-16 text-dark-600 mx-auto mb-4" />
                      <h3 className="text-xl font-semibold text-white mb-2">Aucune commande</h3>
                      <p className="text-dark-300">Vous n'avez pas encore passé de commande</p>
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {orders.map(order => {
                        const StatusIcon = getStatusIcon(order.status);
                        return (
                          <div key={order._id} className="bg-dark-800 rounded-lg p-6">
                            <div className="flex items-center justify-between mb-4">
                              <div>
                                <h3 className="font-semibold text-white">
                                  Commande #{order._id.slice(-8)}
                                </h3>
                                <p className="text-sm text-dark-300">
                                  {new Date(order.createdAt).toLocaleDateString('fr-FR')}
                                </p>
                              </div>
                              <div className="flex items-center">
                                <StatusIcon className={`w-5 h-5 mr-2 ${getStatusColor(order.status)}`} />
                                <span className={`font-medium ${getStatusColor(order.status)}`}>
                                  {getStatusText(order.status)}
                                </span>
                              </div>
                            </div>
                            
                            <div className="space-y-2">
                              {order.items.map((item, index) => (
                                <div key={index} className="flex items-center justify-between text-sm">
                                  <span className="text-dark-300">
                                    {item.quantity}x {item.name}
                                  </span>
                                  <span className="text-white">{item.price}€</span>
                                </div>
                              ))}
                            </div>
                            
                            <div className="border-t border-dark-700 mt-4 pt-4 flex justify-between">
                              <span className="font-semibold text-white">Total</span>
                              <span className="font-semibold text-white">{order.totalAmount}€</span>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'favorites' && (
                <div>
                  <h2 className="text-2xl font-semibold text-white mb-6">Recettes favorites</h2>
                  <div className="text-center py-12">
                    <Heart className="w-16 h-16 text-dark-600 mx-auto mb-4" />
                    <h3 className="text-xl font-semibold text-white mb-2">Aucune recette favorite</h3>
                    <p className="text-dark-300">Ajoutez des recettes à vos favoris en cliquant sur le cœur</p>
                  </div>
                </div>
              )}

              {activeTab === 'settings' && (
                <div>
                  <h2 className="text-2xl font-semibold text-white mb-6">Paramètres</h2>
                  <div className="space-y-6">
                    <div>
                      <h3 className="text-lg font-medium text-white mb-4">Notifications</h3>
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <span className="text-dark-300">Nouvelles recettes</span>
                          <input type="checkbox" className="rounded border-dark-600 bg-dark-800 text-primary-600" />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-dark-300">Nouveaux surplus</span>
                          <input type="checkbox" className="rounded border-dark-600 bg-dark-800 text-primary-600" />
                        </div>
                        <div className="flex items-center justify-between">
                          <span className="text-dark-300">Statut des commandes</span>
                          <input type="checkbox" className="rounded border-dark-600 bg-dark-800 text-primary-600" defaultChecked />
                        </div>
                      </div>
                    </div>
                    
                    <div className="border-t border-dark-800 pt-6">
                      <button
                        onClick={logout}
                        className="bg-red-600 hover:bg-red-700 text-white px-6 py-2 rounded-lg transition-colors"
                      >
                        Se déconnecter
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Profile;
