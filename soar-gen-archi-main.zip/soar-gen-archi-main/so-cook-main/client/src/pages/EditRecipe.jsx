import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { Plus, X, ArrowLeft } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";

const EditRecipe = () => {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    ingredients: [""],
    instructions: [""],
    cookingTime: "",
    difficulty: "Facile",
    category: "Plats",
    season: "Toute saison",
    image: "",
    localIngredients: true,
  });
  const [loading, setLoading] = useState(false);
  const [fetchLoading, setFetchLoading] = useState(true);
  const [error, setError] = useState("");
  const { user } = useAuth();
  const { id } = useParams();
  const navigate = useNavigate();

  const categories = [
    "Entrées",
    "Plats",
    "Desserts",
    "Soupes",
    "Salades",
    "Snacks",
  ];
  const difficulties = ["Facile", "Moyen", "Difficile"];
  const seasons = ["Printemps", "Été", "Automne", "Hiver", "Toute saison"];

  useEffect(() => {
    fetchRecipe();
  }, [id]);

  const fetchRecipe = async () => {
    try {
      const response = await api.get(`/recipes/${id}`);
      const recipe = response.data;

      if (recipe.author !== user?.username) {
        navigate("/recipes");
        return;
      }

      setFormData({
        title: recipe.title,
        description: recipe.description,
        ingredients: recipe.ingredients,
        instructions: recipe.instructions,
        cookingTime: recipe.cookingTime.toString(),
        difficulty: recipe.difficulty,
        category: recipe.category,
        season: recipe.season,
        image: recipe.image,
        localIngredients: recipe.localIngredients,
      });
    } catch (error) {
      console.error("Error fetching recipe:", error);
      navigate("/recipes");
    } finally {
      setFetchLoading(false);
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleArrayInputChange = (index, value, field) => {
    setFormData((prev) => ({
      ...prev,
      [field]: prev[field].map((item, i) => (i === index ? value : item)),
    }));
  };

  const addArrayItem = (field) => {
    setFormData((prev) => ({
      ...prev,
      [field]: [...prev[field], ""],
    }));
  };

  const removeArrayItem = (index, field) => {
    setFormData((prev) => ({
      ...prev,
      [field]: prev[field].filter((_, i) => i !== index),
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!user) return;

    setLoading(true);
    setError("");

    try {
      const recipeData = {
        ...formData,
        ingredients: formData.ingredients.filter((ing) => ing.trim() !== ""),
        instructions: formData.instructions.filter(
          (inst) => inst.trim() !== ""
        ),
        cookingTime: parseInt(formData.cookingTime),
      };

      await api.put(`/recipes/${id}`, recipeData);
      navigate(`/recipes/${id}`);
    } catch (error) {
      setError(
        error.response?.data?.error ||
          "Erreur lors de la modification de la recette"
      );
    } finally {
      setLoading(false);
    }
  };

  if (fetchLoading) {
    return (
      <div className="min-h-screen bg-dark-950 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse">
            <div className="h-8 bg-dark-800 rounded w-1/4 mb-8"></div>
            <div className="card p-8">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div className="space-y-6">
                  {[...Array(5)].map((_, i) => (
                    <div key={i} className="h-20 bg-dark-800 rounded"></div>
                  ))}
                </div>
                <div className="space-y-6">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="h-32 bg-dark-800 rounded"></div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-950 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center mb-8">
          <button
            onClick={() => navigate(`/recipes/${id}`)}
            className="flex items-center text-dark-300 hover:text-white transition-colors mr-4"
          >
            <ArrowLeft className="w-5 h-5 mr-2" />
            Retour à la recette
          </button>
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">
              Modifier la recette
            </h1>
            <p className="text-dark-300">Apportez vos modifications</p>
          </div>
        </div>

        {error && (
          <div className="bg-red-500 bg-opacity-10 border border-red-500 text-red-400 px-4 py-2 rounded-lg mb-6">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="card p-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Basic Info */}
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-dark-300 mb-2">
                  Titre de la recette *
                </label>
                <input
                  type="text"
                  name="title"
                  value={formData.title}
                  onChange={handleInputChange}
                  className="input w-full"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-dark-300 mb-2">
                  Description *
                </label>
                <textarea
                  name="description"
                  value={formData.description}
                  onChange={handleInputChange}
                  rows={4}
                  className="input w-full"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-dark-300 mb-2">
                    Temps de cuisson (min) *
                  </label>
                  <input
                    type="number"
                    name="cookingTime"
                    value={formData.cookingTime}
                    onChange={handleInputChange}
                    className="input w-full"
                    min="1"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-300 mb-2">
                    Difficulté *
                  </label>
                  <select
                    name="difficulty"
                    value={formData.difficulty}
                    onChange={handleInputChange}
                    className="input w-full"
                  >
                    {difficulties.map((diff) => (
                      <option key={diff} value={diff}>
                        {diff}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-dark-300 mb-2">
                    Catégorie *
                  </label>
                  <select
                    name="category"
                    value={formData.category}
                    onChange={handleInputChange}
                    className="input w-full"
                  >
                    {categories.map((cat) => (
                      <option key={cat} value={cat}>
                        {cat}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-dark-300 mb-2">
                    Saison *
                  </label>
                  <select
                    name="season"
                    value={formData.season}
                    onChange={handleInputChange}
                    className="input w-full"
                  >
                    {seasons.map((season) => (
                      <option key={season} value={season}>
                        {season}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="flex items-center">
                <input
                  type="checkbox"
                  name="localIngredients"
                  checked={formData.localIngredients}
                  onChange={handleInputChange}
                  className="rounded border-dark-600 bg-dark-800 text-primary-600 focus:ring-primary-500"
                />
                <label className="ml-2 text-sm text-dark-300">
                  Cette recette utilise des ingrédients locaux
                </label>
              </div>
            </div>

            {/* Ingredients and Instructions */}
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-medium text-dark-300 mb-2">
                  Ingrédients *
                </label>
                {formData.ingredients.map((ingredient, index) => (
                  <div key={index} className="flex gap-2 mb-2">
                    <input
                      type="text"
                      value={ingredient}
                      onChange={(e) =>
                        handleArrayInputChange(
                          index,
                          e.target.value,
                          "ingredients"
                        )
                      }
                      placeholder="Ex: 200g de tomates cerises"
                      className="input flex-1"
                    />
                    {formData.ingredients.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeArrayItem(index, "ingredients")}
                        className="p-2 text-red-400 hover:text-red-300"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => addArrayItem("ingredients")}
                  className="btn-secondary text-sm"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Ajouter un ingrédient
                </button>
              </div>

              <div>
                <label className="block text-sm font-medium text-dark-300 mb-2">
                  Instructions *
                </label>
                {formData.instructions.map((instruction, index) => (
                  <div key={index} className="flex gap-2 mb-2">
                    <textarea
                      value={instruction}
                      onChange={(e) =>
                        handleArrayInputChange(
                          index,
                          e.target.value,
                          "instructions"
                        )
                      }
                      placeholder={`Étape ${index + 1}`}
                      rows={2}
                      className="input flex-1"
                    />
                    {formData.instructions.length > 1 && (
                      <button
                        type="button"
                        onClick={() => removeArrayItem(index, "instructions")}
                        className="p-2 text-red-400 hover:text-red-300"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                ))}
                <button
                  type="button"
                  onClick={() => addArrayItem("instructions")}
                  className="btn-secondary text-sm"
                >
                  <Plus className="w-4 h-4 mr-1" />
                  Ajouter une étape
                </button>
              </div>
            </div>
          </div>

          <div className="mt-8 flex justify-end space-x-4">
            <button
              type="button"
              onClick={() => navigate(`/recipes/${id}`)}
              className="btn-secondary"
            >
              Annuler
            </button>
            <button
              type="submit"
              disabled={loading}
              className="btn-primary disabled:opacity-50"
            >
              {loading ? "Modification..." : "Modifier la recette"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default EditRecipe;
