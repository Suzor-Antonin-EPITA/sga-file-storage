import React from 'react';
import { Link } from 'react-router-dom';
import { ChefHat, Store, Recycle, Users, Leaf, Heart } from 'lucide-react';

const Home = () => {
  const features = [
    {
      icon: ChefHat,
      title: 'Recettes Locales',
      description: 'Découvrez des recettes créées avec des ingrédients issus des jardins potagers parisiens',
      link: '/recipes'
    },
    {
      icon: Store,
      title: 'Marketplace',
      description: 'Achetez des produits frais et locaux directement auprès des producteurs',
      link: '/marketplace'
    },
    {
      icon: Recycle,
      title: 'Anti-Gaspillage',
      description: 'Récupérez les surplus alimentaires à prix réduit et luttez contre le gaspillage',
      link: '/surplus'
    }
  ];

  const stats = [
    { icon: Users, value: '2,500+', label: 'Utilisateurs actifs' },
    { icon: Leaf, value: '1,200+', label: 'Recettes locales' },
    { icon: Heart, value: '85%', label: 'Satisfaction' }
  ];

  return (
    <div className="min-h-screen bg-dark-950">
      {/* Hero Section */}
      <section className="hero-gradient py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            Cultivons l'autonomie
            <span className="text-primary-400 block">alimentaire parisienne</span>
          </h1>
          <p className="text-xl text-dark-200 mb-8 max-w-3xl mx-auto">
            So-Cook connecte les citoyens autour de l'alimentation locale. 
            Partagez des recettes, achetez des produits frais et luttez contre le gaspillage.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/recipes" className="btn-primary text-lg px-8 py-3">
              Découvrir les recettes
            </Link>
            <Link to="/marketplace" className="btn-secondary text-lg px-8 py-3">
              Explorer le marketplace
            </Link>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Une plateforme, trois missions
            </h2>
            <p className="text-xl text-dark-300 max-w-2xl mx-auto">
              So-Cook rassemble tout ce dont vous avez besoin pour une alimentation locale et responsable
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Link
                  key={index}
                  to={feature.link}
                  className="card p-8 text-center hover:scale-105 transform transition-all duration-200 group"
                >
                  <div className="w-16 h-16 bg-primary-600 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:bg-primary-500 transition-colors">
                    <Icon className="w-8 h-8 text-white" />
                  </div>
                  <h3 className="text-xl font-semibold text-white mb-4">
                    {feature.title}
                  </h3>
                  <p className="text-dark-300 leading-relaxed">
                    {feature.description}
                  </p>
                </Link>
              );
            })}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 bg-dark-900">
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div key={index} className="space-y-2">
                  <Icon className="w-8 h-8 text-primary-400 mx-auto" />
                  <div className="text-3xl font-bold text-white">{stat.value}</div>
                  <div className="text-dark-300">{stat.label}</div>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Rejoignez la communauté So-Cook
          </h2>
          <p className="text-xl text-dark-300 mb-8">
            Ensemble, construisons un système alimentaire plus local, plus durable et plus solidaire
          </p>
          <Link to="/recipes" className="btn-primary text-lg px-8 py-3">
            Commencer maintenant
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;