import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, ShoppingCart, Clock, MapPin, AlertTriangle, Package, TrendingDown } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';

const SurplusDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { user } = useAuth();
  const [surplus, setSurplus] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    loadSurplus();
  }, [id]);

  const loadSurplus = async () => {
    try {
      const response = await api.get(`/surplus/${id}`);
      setSurplus(response.data);
    } catch (error) {
      setError('Surplus non trouvé');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = async () => {
    if (!user) {
      alert('Veuillez vous connecter pour réserver ce surplus');
      return;
    }

    const result = await addToCart(surplus, quantity, 'surplus');
    if (result.success) {
      alert('Surplus ajouté au panier !');
    }
  };

  const getStatusInfo = (status, availableQuantity, reserved) => {
    const remaining = availableQuantity - reserved;
    switch (status) {
      case 'available':
        return { text: `${remaining} disponibles`, color: 'text-green-400', bgColor: 'bg-green-400/10' };
      case 'limited':
        return { text: `Plus que ${remaining}`, color: 'text-yellow-400', bgColor: 'bg-yellow-400/10' };
      case 'soldout':
        return { text: 'Épuisé', color: 'text-red-400', bgColor: 'bg-red-400/10' };
      default:
        return { text: 'Indisponible', color: 'text-dark-400', bgColor: 'bg-dark-800' };
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="animate-pulse">
          <div className="h-8 bg-dark-800 rounded mb-4 w-1/3"></div>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="h-96 bg-dark-800 rounded"></div>
            <div className="space-y-4">
              <div className="h-8 bg-dark-800 rounded"></div>
              <div className="h-4 bg-dark-800 rounded w-2/3"></div>
              <div className="h-6 bg-dark-800 rounded w-1/2"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !surplus) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Surplus non trouvé</h1>
          <button
            onClick={() => navigate('/surplus')}
            className="btn-primary"
          >
            Retour aux surplus
          </button>
        </div>
      </div>
    );
  }

  const statusInfo = getStatusInfo(surplus.status, surplus.availableQuantity, surplus.reserved);
  const discountPercentage = Math.round((1 - surplus.discountedPrice / surplus.originalPrice) * 100);
  const hoursUntilExpiry = Math.ceil((new Date(surplus.expiryDate) - new Date()) / (1000 * 60 * 60));
  const maxQuantity = Math.min(quantity, surplus.availableQuantity - surplus.reserved);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <button
        onClick={() => navigate('/surplus')}
        className="flex items-center text-primary-400 hover:text-primary-300 mb-6 transition-colors"
      >
        <ArrowLeft className="w-5 h-5 mr-2" />
        Retour aux surplus
      </button>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Image */}
        <div className="aspect-square bg-dark-800 rounded-xl overflow-hidden relative">
          <img
            src={surplus.image}
            alt={surplus.title}
            className="w-full h-full object-cover"
          />
          
          {/* Discount Badge */}
          <div className="absolute top-4 left-4">
            <div className="bg-red-500 text-white px-3 py-1 rounded-full text-sm font-bold flex items-center">
              <TrendingDown className="w-4 h-4 mr-1" />
              -{discountPercentage}%
            </div>
          </div>

          {/* Status Badge */}
          <div className="absolute top-4 right-4">
            <div className={`${statusInfo.bgColor} ${statusInfo.color} px-3 py-1 rounded-full text-sm font-medium border border-current`}>
              {statusInfo.text}
            </div>
          </div>
        </div>

        {/* Surplus Info */}
        <div className="space-y-6">
          <div>
            <h1 className="text-3xl font-bold text-white mb-2">{surplus.title}</h1>
            <p className="text-dark-300">{surplus.description}</p>
          </div>

          {/* Price */}
          <div className="flex items-center space-x-4">
            <span className="text-2xl text-dark-500 line-through">
              {surplus.originalPrice.toFixed(2)}€
            </span>
            <span className="text-3xl font-bold text-primary-400">
              {surplus.discountedPrice.toFixed(2)}€
            </span>
          </div>

          {/* Items */}
          <div>
            <h3 className="text-lg font-semibold text-white mb-3">Contenu du panier</h3>
            <div className="grid grid-cols-2 gap-2">
              {surplus.items.map((item, index) => (
                <div key={index} className="bg-dark-800 text-dark-300 px-3 py-2 rounded-lg text-sm">
                  {item}
                </div>
              ))}
            </div>
          </div>

          {/* Meta Info */}
          <div className="space-y-3">
            <div className="flex items-center text-dark-300">
              <MapPin className="w-5 h-5 mr-3 text-primary-400" />
              {surplus.location}
            </div>
            <div className="flex items-center text-dark-300">
              <Clock className="w-5 h-5 mr-3 text-primary-400" />
              Récupération: {surplus.pickupTimeStart} - {surplus.pickupTimeEnd}
            </div>
            <div className="flex items-center text-dark-300">
              <Package className="w-5 h-5 mr-3 text-primary-400" />
              Catégorie: {surplus.category}
            </div>
          </div>

          {/* Expiry Warning */}
          {hoursUntilExpiry <= 24 && hoursUntilExpiry > 0 && (
            <div className="bg-yellow-500 bg-opacity-10 border border-yellow-500 text-yellow-400 p-4 rounded-lg flex items-center">
              <AlertTriangle className="w-5 h-5 mr-3" />
              <div>
                <p className="font-medium">Expire bientôt !</p>
                <p className="text-sm">Plus que {hoursUntilExpiry}h pour récupérer ce surplus</p>
              </div>
            </div>
          )}

          {/* Quantity and Add to Cart */}
          {surplus.status !== 'soldout' && hoursUntilExpiry > 0 && (
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-dark-300 mb-2">
                  Quantité
                </label>
                <div className="flex items-center space-x-3">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="w-10 h-10 bg-dark-800 hover:bg-dark-700 text-white rounded-lg transition-colors"
                  >
                    -
                  </button>
                  <span className="text-xl font-medium text-white w-16 text-center">
                    {quantity}
                  </span>
                  <button
                    onClick={() => setQuantity(Math.min(maxQuantity, quantity + 1))}
                    className="w-10 h-10 bg-dark-800 hover:bg-dark-700 text-white rounded-lg transition-colors"
                  >
                    +
                  </button>
                </div>
                <p className="text-sm text-dark-400 mt-1">
                  {surplus.availableQuantity - surplus.reserved} sur {surplus.availableQuantity} disponible{surplus.availableQuantity > 1 ? 's' : ''}
                </p>
              </div>

              <button
                onClick={handleAddToCart}
                className="btn-primary w-full flex items-center justify-center"
              >
                <ShoppingCart className="w-5 h-5 mr-2" />
                Réserver ce surplus
              </button>
            </div>
          )}

          {/* Seller Info */}
          <div className="bg-dark-800 rounded-lg p-4">
            <h3 className="font-semibold text-white mb-2">Vendeur</h3>
            <p className="text-dark-300">{surplus.seller}</p>
          </div>

          {/* Pickup Instructions */}
          <div className="bg-primary-600 bg-opacity-10 border border-primary-600 text-primary-300 p-4 rounded-lg">
            <h3 className="font-semibold mb-2">Instructions de récupération</h3>
            <p className="text-sm">
              Récupérez votre surplus entre {surplus.pickupTimeStart} et {surplus.pickupTimeEnd} 
              à l'adresse indiquée. Pensez à apporter un sac ou un contenant.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SurplusDetail;
