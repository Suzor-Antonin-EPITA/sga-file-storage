import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";

const AddProduct = () => {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    unit: "kg",
    category: "Fruits",
    image: "https://via.placeholder.com/300x300",
    seller: "",
    location: "",
    availability: "",
    organic: false,
    local: true,
    harvestDate: "",
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const { user } = useAuth();
  const navigate = useNavigate();

  const categories = ["Fruits", "Légumes", "Viandes", "Produits laitiers", "Boissons", "Autres"];
  const units = ["kg", "pièce", "litre"];

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!user) return;
    setLoading(true);
    setError("");
    try {
      const productData = {
        ...formData,
        price: parseFloat(formData.price),
        availability: parseInt(formData.availability),
        seller: user.username,
        harvestDate: formData.harvestDate ? new Date(formData.harvestDate) : undefined,
      };
      await api.post("/products", productData);
      navigate("/marketplace");
    } catch (error) {
      setError(
        error.response?.data?.error || "Erreur lors de la création du produit"
      );
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-dark-950 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Connexion requise</h1>
          <p className="text-dark-300">Vous devez être connecté pour ajouter un produit.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-dark-950 py-8">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Ajouter un produit</h1>
          <p className="text-dark-300">Ajoutez un produit à vendre sur le marché</p>
        </div>
        {error && (
          <div className="bg-red-500 bg-opacity-10 border border-red-500 text-red-400 px-4 py-2 rounded-lg mb-6">{error}</div>
        )}
        <form onSubmit={handleSubmit} className="card p-8 space-y-6">
          <div>
            <label className="block text-sm font-medium text-dark-300 mb-2">Nom du produit *</label>
            <input type="text" name="name" value={formData.name} onChange={handleInputChange} className="input w-full" required />
          </div>
          <div>
            <label className="block text-sm font-medium text-dark-300 mb-2">Description *</label>
            <textarea name="description" value={formData.description} onChange={handleInputChange} rows={3} className="input w-full" required />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-dark-300 mb-2">Prix (€) *</label>
              <input type="number" name="price" value={formData.price} onChange={handleInputChange} className="input w-full" min="0" step="0.01" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-300 mb-2">Unité *</label>
              <select name="unit" value={formData.unit} onChange={handleInputChange} className="input w-full">
                {units.map((unit) => (
                  <option key={unit} value={unit}>{unit}</option>
                ))}
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-dark-300 mb-2">Catégorie *</label>
              <select name="category" value={formData.category} onChange={handleInputChange} className="input w-full">
                {categories.map((cat) => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-300 mb-2">Image (URL)</label>
              <input type="text" name="image" value={formData.image} onChange={handleInputChange} className="input w-full" />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-dark-300 mb-2">Lieu *</label>
              <input type="text" name="location" value={formData.location} onChange={handleInputChange} className="input w-full" required />
            </div>
            <div>
              <label className="block text-sm font-medium text-dark-300 mb-2">Quantité disponible *</label>
              <input type="number" name="availability" value={formData.availability} onChange={handleInputChange} className="input w-full" min="0" required />
            </div>
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center">
              <input type="checkbox" name="organic" checked={formData.organic} onChange={handleInputChange} className="rounded border-dark-600 bg-dark-800 text-primary-600 focus:ring-primary-500" />
              <label className="ml-2 text-sm text-dark-300">Bio</label>
            </div>
            <div className="flex items-center">
              <input type="checkbox" name="local" checked={formData.local} onChange={handleInputChange} className="rounded border-dark-600 bg-dark-800 text-primary-600 focus:ring-primary-500" />
              <label className="ml-2 text-sm text-dark-300">Local</label>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-dark-300 mb-2">Date de récolte</label>
            <input type="date" name="harvestDate" value={formData.harvestDate} onChange={handleInputChange} className="input w-full" />
          </div>
          <div className="mt-8 flex justify-end space-x-4">
            <button type="button" onClick={() => navigate("/marketplace")} className="btn-secondary">Annuler</button>
            <button type="submit" disabled={loading} className="btn-primary disabled:opacity-50">{loading ? "Création..." : "Créer le produit"}</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default AddProduct;
