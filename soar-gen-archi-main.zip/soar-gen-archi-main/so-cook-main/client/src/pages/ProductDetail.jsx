import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, ShoppingCart, Star, MapPin, Calendar, Leaf } from 'lucide-react';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import api from '../services/api';

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { user } = useAuth();
  const [product, setProduct] = useState(null);
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    loadProduct();
  }, [id]);

  const loadProduct = async () => {
    try {
      const response = await api.get(`/products/${id}`);
      setProduct(response.data);
    } catch (error) {
      setError('Produit non trouvé');
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = async () => {
    if (!user) {
      alert('Veuillez vous connecter pour ajouter des produits au panier');
      return;
    }

    const result = await addToCart(product, quantity, 'product');
    if (result.success) {
      alert('Produit ajouté au panier !');
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="animate-pulse">
          <div className="h-8 bg-dark-800 rounded mb-4 w-1/3"></div>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="h-96 bg-dark-800 rounded"></div>
            <div className="space-y-4">
              <div className="h-8 bg-dark-800 rounded"></div>
              <div className="h-4 bg-dark-800 rounded w-2/3"></div>
              <div className="h-6 bg-dark-800 rounded w-1/2"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-white mb-4">Produit non trouvé</h1>
          <button
            onClick={() => navigate('/marketplace')}
            className="btn-primary"
          >
            Retour au marketplace
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <button
        onClick={() => navigate('/marketplace')}
        className="flex items-center text-primary-400 hover:text-primary-300 mb-6 transition-colors"
      >
        <ArrowLeft className="w-5 h-5 mr-2" />
        Retour au marketplace
      </button>

      <div className="grid md:grid-cols-2 gap-8">
        {/* Image */}
        <div className="aspect-square bg-dark-800 rounded-xl overflow-hidden">
          <img
            src={product.image}
            alt={product.name}
            className="w-full h-full object-cover"
          />
        </div>

        {/* Product Info */}
        <div className="space-y-6">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <h1 className="text-3xl font-bold text-white">{product.name}</h1>
              {product.organic && (
                <span className="bg-green-500 bg-opacity-20 text-green-400 px-2 py-1 rounded-full text-xs font-medium border border-green-400 flex items-center">
                  <Leaf className="w-3 h-3 mr-1" />
                  Bio
                </span>
              )}
            </div>
            <p className="text-dark-300">{product.description}</p>
          </div>

          {/* Price */}
          <div className="text-3xl font-bold text-primary-400">
            {product.price.toFixed(2)}€ <span className="text-lg text-dark-400">/ {product.unit}</span>
          </div>

          {/* Meta Info */}
          <div className="space-y-3">
            <div className="flex items-center text-dark-300">
              <MapPin className="w-5 h-5 mr-3 text-primary-400" />
              {product.location}
            </div>
            {product.harvestDate && (
              <div className="flex items-center text-dark-300">
                <Calendar className="w-5 h-5 mr-3 text-primary-400" />
                Récolté le {new Date(product.harvestDate).toLocaleDateString()}
              </div>
            )}
            <div className="flex items-center text-dark-300">
              <Star className="w-5 h-5 mr-3 text-primary-400" />
              {product.rating.toFixed(1)} / 5 ({product.reviews.length} avis)
            </div>
          </div>

          {/* Quantity and Add to Cart */}
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-dark-300 mb-2">
                Quantité
              </label>
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-10 h-10 bg-dark-800 hover:bg-dark-700 text-white rounded-lg transition-colors"
                >
                  -
                </button>
                <span className="text-xl font-medium text-white w-16 text-center">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity(Math.min(product.availability, quantity + 1))}
                  className="w-10 h-10 bg-dark-800 hover:bg-dark-700 text-white rounded-lg transition-colors"
                >
                  +
                </button>
              </div>
              <p className="text-sm text-dark-400 mt-1">
                {product.availability} disponible{product.availability > 1 ? 's' : ''}
              </p>
            </div>

            <button
              onClick={handleAddToCart}
              disabled={product.availability === 0}
              className="btn-primary w-full flex items-center justify-center disabled:opacity-50"
            >
              <ShoppingCart className="w-5 h-5 mr-2" />
              Ajouter au panier
            </button>
          </div>

          {/* Seller Info */}
          <div className="bg-dark-800 rounded-lg p-4">
            <h3 className="font-semibold text-white mb-2">Vendeur</h3>
            <p className="text-dark-300">{product.seller}</p>
          </div>
        </div>
      </div>

      {/* Reviews */}
      {product.reviews.length > 0 && (
        <div className="mt-12">
          <h2 className="text-2xl font-bold text-white mb-6">Avis clients</h2>
          <div className="space-y-4">
            {product.reviews.map((review, index) => (
              <div key={index} className="bg-dark-800 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-white">{review.user}</span>
                  <div className="flex items-center">
                    {[...Array(5)].map((_, i) => (
                      <Star
                        key={i}
                        className={`w-4 h-4 ${
                          i < review.rating ? 'text-yellow-400 fill-current' : 'text-dark-600'
                        }`}
                      />
                    ))}
                  </div>
                </div>
                <p className="text-dark-300">{review.comment}</p>
                <p className="text-dark-500 text-sm mt-2">
                  {new Date(review.date).toLocaleDateString()}
                </p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default ProductDetail;
