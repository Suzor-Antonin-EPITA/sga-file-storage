import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Home from './pages/Home'
import Recipes from './pages/Recipes'
import RecipeDetail from './pages/RecipeDetail'
import Marketplace from './pages/Marketplace'
import ProductDetail from './pages/ProductDetail'
import Surplus from './pages/Surplus'
import SurplusDetail from './pages/SurplusDetail'
import Cart from './pages/Cart'
import Profile from './pages/Profile'
import AddRecipe from './pages/AddRecipe'
import EditRecipe from './pages/EditRecipe'
import TestPage from './pages/TestPage'
import AddProduct from './pages/AddProduct'

function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/recipes" element={<Recipes />} />
        <Route path="/recipes/:id" element={<RecipeDetail />} />
        <Route path="/recipes/add" element={<AddRecipe />} />
        <Route path="/recipes/edit/:id" element={<EditRecipe />} />
        <Route path="/marketplace" element={<Marketplace />} />
        <Route path="/marketplace/add" element={<AddProduct />} />
        <Route path="/marketplace/:id" element={<ProductDetail />} />
        <Route path="/surplus" element={<Surplus />} />
        <Route path="/surplus/:id" element={<SurplusDetail />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/profile" element={<Profile />} />
        <Route path="/test" element={<TestPage />} />
      </Routes>
    </Layout>
  )
}

export default App
