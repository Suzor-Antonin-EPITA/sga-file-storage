import http from 'k6/http';
import { sleep } from 'k6';

export const options = {
  stages: [
    { duration: '10s', target: 1 },
    { duration: '10s', target: 200 },
    { duration: '20s', target: 300 },
    { duration: '10s', target: 10 },
  ],
};

const BASE_URL = 'https://t1-gena-pl3.antonin-suzor.com';

export default function () {
    const payload = JSON.stringify({
        title: "Sandwich au pain",
        description: "oui oui, c'est pas mal, je vous jure",
        ingredients: ["pain de type 1", "pain de type 2"],
        instructions: ["prendre 2 tranches de pain 1", "mettre une tranche de pain 2 au milieu"],
        cookingTime: 1,
        difficulty: "Facile",
        category: "Snacks",
        season: "Toute saison",
        image: "https://raw.githubusercontent.com/Suzor-Antonin-EPITA/sga-file-storage/main/sandwich-pain-mini.jpg",
        localIngredients: false,
        author: "asuzor"
    });
    const params = {
      headers: {
        'Content-Type': 'application/json',
      },
    };

    const res = http.post(`${BASE_URL}/api/recipes`, payload, params);
    const id = res.json("_id")
    sleep(1);

    http.put(`${BASE_URL}/api/recipes/${id}`, payload, params);
    sleep(1);
    http.put(`${BASE_URL}/api/recipes/${id}`, payload, params);
    sleep(1);
    http.put(`${BASE_URL}/api/recipes/${id}`, payload, params);
    sleep(1);
    http.put(`${BASE_URL}/api/recipes/${id}`, payload, params);
    sleep(1);
    http.put(`${BASE_URL}/api/recipes/${id}`, payload, params);
}
