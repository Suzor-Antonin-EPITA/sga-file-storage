import http from 'k6/http';

export const options = {
  stages: [
    { duration: '10s', target: 1 },
    { duration: '10s', target: 200 },
    { duration: '20s', target: 300 },
    { duration: '10s', target: 10 },
  ],
};

const BASE_URL = 'https://gena-pl2.antonin-suzor.com';

export default function () {
    http.get(`${BASE_URL}/api/fibo/fibo/20`);
}
