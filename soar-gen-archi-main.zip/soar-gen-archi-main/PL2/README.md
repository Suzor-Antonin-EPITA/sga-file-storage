# so-cook
Projet SOCRA 


# Plateforme 2
terraform init
terraform plan
terraform apply -auto-approve 
terraform destroy -auto-approve


# Test Backend SSH
ssh -i ~/.ssh/key.pem ec2-user@id-back
pm2 list
curl http://localhost:3000/health
curl http://localhost:3000/api/health
curl http://<ip_publique_back>:3000/health

# Test frontend SSH
ssh -i ~/.ssh/key.pem ec2-user@id-front
sudo systemctl status nginx
curl -I http://localhost
curl -I http://<ip_publique_front>
curl http://<ip_privée_back>:3000/health

# Test DB SSH
sudo systemctl status mongod
mongo --eval 'db.runCommand({ connectionStatus: 1 })'

# Test via ALB
alb=$(terraform output -raw alb_dns_name)
echo "Front :"; curl -I http://$alb
echo "Back :"; curl http://$alb/api/health

# Récupérer l'url publique 
terraform output alb_dns_name







# Test Backend
aws ec2 describe-instances \
  --filters "Name=tag:Name,Values=*back*" \
  --query "Reservations[*].Instances[*].InstanceId" \
  --output text

aws ssm start-session --target <id_instance_back>
pm2 list
curl http://localhost:3000/health

# Test frontend
aws ec2 describe-instances \
  --filters "Name=tag:Name,Values=*front*" \
  --query "Reservations[*].Instances[*].InstanceId" \
  --output text

aws ssm start-session --target <id_instance_front>
sudo systemctl status nginx
pm2 list
http://localhost:5002

# Test DB
aws ec2 describe-instances \
  --filters "Name=tag:Name,Values=*db*" \
  --query "Reservations[*].Instances[*].InstanceId" \
  --output text

aws ssm start-session --target <id_instance_db>
sudo systemctl status mongod
pm2 list