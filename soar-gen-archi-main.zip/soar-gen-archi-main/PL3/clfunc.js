function handler(event) {
    let req = event.request;

    // don't modify api requests
    if (req.uri.startsWith("/api")) {
        return req;
    }

    // don't modify requests for explicit files
    if (req.uri.split('/').pop().includes('.')) {
        return req;
    }

    // rewrite all other requests to React SPA
    req.uri = "/index.html";

    return req;
}
